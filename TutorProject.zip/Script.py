#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
import folium
from folium.plugins import MarkerCluster
import branca.colormap as cm
import os
import json
from collections import defaultdict
from datetime import datetime, timedelta
import random
from folium.plugins import MeasureControl, Fullscreen, MousePosition
import html
import requests
import osmnx as ox
import threading
import time
import csv
import re
import unicodedata
import networkx as nx
from shapely.geometry import Point, LineString
from flask import Flask, request, jsonify, send_from_directory


# Chemins des répertoires
montbeliard_dir = "montbéliard"
belfort_dir = "belfort"
horaires_dir = "data_horaires"  # Nouveau répertoire pour les données FlixBus/FlixTrain

# Configuration de l'API SNCF
SNCF_API_KEY = "4e68d4b6-e7fc-424a-831b-a2f192e0b10d"
SNCF_API_BASE_URL = "https://api.sncf.com/v1"
SNCF_COVERAGE = "sncf"

# Chemin du fichier de données gares SNCF
CSV_FILE_PATH = "gares-de-voyageurs.csv"

# Territoires à afficher pour les gares SNCF
TERRITORIES = [
    "montbéliard",
    "belfort",
    "mulhouse",
    "strasbourg",
    "alsace"
]

# Liste des gares explicitement demandées
ADDITIONAL_STATIONS = [
    "Bas Évette",
    "Colombier-Fontaine",
    "Clerval",
    "Danjoutin",
    "Delle",
    "Grandvillars",
    "Héricourt",
    "Joncherey",
    "L'Isle-sur-le-Doubs",
    "Meroux",
    "Morvillars",
    "Petit-Croix",
    "Ronchamp",
    "Saint-Louis",
    "Saint-Louis La Chaussée",
    "Trois Chênes",
    "Voujeaucourt"
]

# Coordonnées approximatives pour l'aéroport Bâle-Mulhouse (si non trouvé dans les données)
BALE_MULHOUSE_AIRPORT = {"lat": 47.5896, "lon": 7.5299}

# Définition des zones géographiques pour les requêtes Overpass
RAILWAY_ZONES = {
    "Montbéliard-Belfort": {"min_lat": 47.4, "min_lon": 6.5, "max_lat": 47.8, "max_lon": 7.1},
    "Mulhouse": {"min_lat": 47.6, "min_lon": 7.2, "max_lat": 47.9, "max_lon": 7.5},
    "Strasbourg": {"min_lat": 48.5, "min_lon": 7.6, "max_lat": 48.7, "max_lon": 7.9},
    "Alsace": {"min_lat": 47.5, "min_lon": 7.0, "max_lat": 49.0, "max_lon": 8.0}
}

# Cache pour les données ferroviaires et les graphes OSMnx
RAILWAY_CACHE = {}
ROUTE_CACHE = {}
GRAPH_CACHE = {}

# Variables globales pour les données SNCF
ALL_RAILWAY_LINES = []

# Fonction pour normaliser le texte
def normalize_text(text):
    """Normalise un texte pour la recherche (supprime accents, parenthèses, etc.)"""
    if not text:
        return ""
    
    # Convertir en minuscules
    text = text.lower()
    
    # Supprimer les parenthèses et leur contenu
    text = re.sub(r'\([^)]*\)', '', text)
    
    # Supprimer les caractères spéciaux et les accents
    text = ''.join(c for c in unicodedata.normalize('NFD', text))
    
    # Supprimer les caractères non alphanumériques
    text = re.sub(r'[^a-z0-9\s]', '', text)
    
    # Supprimer les espaces multiples et les espaces en début/fin
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Fonction pour charger les gares SNCF depuis le CSV
def load_stations_from_csv(csv_file_path):
    """Charger les gares depuis le fichier CSV"""
    stations = []
    additional_stations_found = set()
    
    try:
        with open(csv_file_path, 'r', encoding='utf-8-sig') as file:
            csv_reader = csv.reader(file, delimiter=';')
            headers = next(csv_reader)  # Lire l'en-tête
            
            for row in csv_reader:
                if len(row) >= 6:  # Vérifier que la ligne a suffisamment de colonnes
                    name = row[0]
                    trigramme = row[1]
                    segment = row[2]
                    
                    # Extraire les coordonnées
                    coords = row[3].split(',')
                    if len(coords) == 2:
                        lat = float(coords[0].strip())
                        lon = float(coords[1].strip())
                    else:
                        continue  # Ignorer les lignes sans coordonnées valides
                    
                    code_insee = row[4]
                    uic_codes = row[5]
                    
                    # Vérifier si c'est une gare explicitement demandée
                    is_additional = False
                    normalized_name = normalize_text(name)
                    
                    for station_name in ADDITIONAL_STATIONS:
                        normalized_station = normalize_text(station_name)
                        if normalized_station in normalized_name or normalized_name in normalized_station:
                            is_additional = True
                            additional_stations_found.add(station_name)
                            break
                    
                    # Filtrer les gares des territoires spécifiés ou les gares explicitement demandées
                    if is_additional or is_station_in_territory(name, lat, lon):
                        station = {
                            "id": f"stop_area:SNCF:{uic_codes.split(';')[0]}",  # Utiliser le premier code UIC
                            "name": name,
                            "normalized_name": normalized_name,
                            "lat": lat,
                            "lon": lon,
                            "trigramme": trigramme,
                            "code_insee": code_insee,
                            "is_additional": is_additional
                        }
                        stations.append(station)
        
        # Afficher les gares demandées qui n'ont pas été trouvées
        not_found = set(ADDITIONAL_STATIONS) - additional_stations_found
        if not_found:
            print(f"Attention: Les gares suivantes n'ont pas été trouvées dans le CSV: {', '.join(not_found)}")
        
        return stations
    except Exception as e:
        print(f"Erreur lors du chargement du CSV: {e}")
        return []

# Fonction pour vérifier si une gare est dans le territoire
def is_station_in_territory(name, lat, lon):
    """Vérifier si une gare appartient aux territoires spécifiés"""
    name_lower = name.lower()
    
    # Vérifier si le nom de la gare contient un des territoires spécifiés
    for territory in TERRITORIES:
        if territory in name_lower:
            return True
    
    # Vérifier si c'est l'aéroport Bâle-Mulhouse (par proximité géographique)
    if (abs(lat - BALE_MULHOUSE_AIRPORT["lat"]) < 0.05 and 
        abs(lon - BALE_MULHOUSE_AIRPORT["lon"]) < 0.05 and
        ("aéroport" in name_lower or "airport" in name_lower)):
        return True
    
    # Vérifier si c'est une gare d'Alsace (par code INSEE)
    if name_lower.startswith("67") or name_lower.startswith("68"):
        return True
    
    return False

# Fonction pour faire une requête à l'API SNCF
def make_sncf_api_request(endpoint, params=None):
    """Faire une requête à l'API SNCF"""
    url = f"{SNCF_API_BASE_URL}/{endpoint}"
    auth = (SNCF_API_KEY, '')
    
    try:
        response = requests.get(url, params=params, auth=auth)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Erreur API: {e}")
        return None

# Fonction pour obtenir les départs d'une gare SNCF
def get_station_departures(station_id, limit=20):
    """Obtenir les départs d'une gare"""
    now = datetime.now().strftime("%Y%m%dT%H%M%S")
    endpoint = f"coverage/{SNCF_COVERAGE}/stop_areas/{station_id}/departures"
    params = {
        "datetime": now,
        "count": limit,
        "disable_geojson": True
    }
    
    response = make_sncf_api_request(endpoint, params)
    if not response or "departures" not in response:
        return []
    
    departures = []
    for departure in response["departures"]:
        display_info = departure.get("display_informations", {})
        stop_time = departure.get("stop_date_time", {})
        
        departure_time = stop_time.get("departure_date_time", "")
        if departure_time:
            try:
                dt = datetime.strptime(departure_time, "%Y%m%dT%H%M%S")
                formatted_time = dt.strftime("%H:%M")
                time_obj = dt.time()
            except ValueError:
                formatted_time = departure_time
                time_obj = datetime.now().time()
        else:
            formatted_time = "Inconnu"
            time_obj = datetime.now().time()
        
        # Vérifier si le départ est dans le futur
        current_time = datetime.now().time()
        if time_obj >= current_time:
            departure_info = {
                "time": formatted_time,
                "direction": display_info.get("direction", "Inconnu"),
                "train_type": display_info.get("commercial_mode", "Train"),
                "number": display_info.get("headsign", ""),
                "platform": departure.get("stop_point", {}).get("name", ""),
                "status": display_info.get("status", ""),
                "departure_time_obj": time_obj,
                "route_id": display_info.get("route_id", ""),
                "trip_id": display_info.get("trip_id", ""),
                "direction_id": display_info.get("direction_id", "")
            }
            departures.append(departure_info)
    
    # Trier par heure de départ
    departures.sort(key=lambda x: x["departure_time_obj"])
    return departures[:limit]

# Fonction pour formater l'heure de l'API SNCF
def format_api_datetime(api_datetime):
    """Formater une date/heure de l'API"""
    if not api_datetime:
        return "Inconnu"
    try:
        dt = datetime.strptime(api_datetime, "%Y%m%dT%H%M%S")
        return dt.strftime("%H:%M")
    except ValueError:
        return api_datetime

# Fonction pour formater la durée
def format_duration(seconds):
    """Formater une durée en secondes"""
    if not seconds:
        return "Inconnu"
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    return f"{hours}h{minutes:02d}" if hours > 0 else f"{minutes}min"

# Fonction pour trouver la meilleure correspondance de gare
def find_best_matching_station(stations, destination_name):
    """Trouver la meilleure correspondance de gare pour une destination donnée"""
    if not destination_name or not stations:
        return None
    
    # Normaliser le nom de destination pour la recherche
    normalized_dest = normalize_text(destination_name)
    
    # Si le nom normalisé est vide, retourner None
    if not normalized_dest:
        return None
    
    # Diviser le nom en mots pour une recherche plus précise
    dest_words = normalized_dest.split()
    
    # Recherche exacte
    for station in stations:
        if station["normalized_name"] == normalized_dest:
            return station
    
    # Recherche par correspondance partielle (début du nom)
    for station in stations:
        if station["normalized_name"].startswith(normalized_dest):
            return station
    
    # Recherche par mots-clés (tous les mots doivent être présents)
    best_match = None
    best_score = 0
    
    for station in stations:
        station_name = station["normalized_name"]
        score = 0
        
        # Calculer un score basé sur le nombre de mots correspondants
        for word in dest_words:
            if word in station_name:
                score += 1
        
        # Si tous les mots sont présents, c'est une correspondance parfaite
        if score == len(dest_words) and score > best_score:
            best_match = station
            best_score = score
    
    # Si on a trouvé une correspondance avec tous les mots, la retourner
    if best_match:
        return best_match
    
    # Recherche par correspondance partielle (contient)
    for station in stations:
        if normalized_dest in station["normalized_name"]:
            return station
    
    # Recherche par premier mot (souvent le nom principal de la ville)
    if dest_words:
        first_word = dest_words[0]
        for station in stations:
            if station["normalized_name"].startswith(first_word):
                return station
    
    # Aucune correspondance trouvée
    return None

# Fonction pour récupérer les données ferroviaires
def fetch_railway_data(zone_name, zone_coords):
    """Récupérer les données ferroviaires avec logique de retry."""
    # Vérifier si les données sont en cache
    if zone_name in RAILWAY_CACHE:
        return RAILWAY_CACHE[zone_name]
    
    overpass_url = "http://overpass-api.de/api/interpreter"
    overpass_query = f"""
    [out:json];
    (
      way["railway"="rail"]({zone_coords['min_lat']},{zone_coords['min_lon']},{zone_coords['max_lat']},{zone_coords['max_lon']});
    );
    out geom;
    """
    
    try:
        response = requests.get(overpass_url, params={'data': overpass_query}, timeout=15)
        response.raise_for_status()
        data = response.json()
        
        # Mettre en cache les données
        RAILWAY_CACHE[zone_name] = data
        
        return data
    except requests.exceptions.RequestException as e:
        print(f"Erreur lors de la récupération des données ferroviaires pour {zone_name}: {e}")
        return None

# Fonction pour créer un popup amélioré pour les voies ferrées
def create_enhanced_railway_popup(element):
    """Créer un popup amélioré pour les voies ferrées."""
    tags = element.get('tags', {})
    
    # Récupérer les informations pertinentes
    railway_type = tags.get('railway', 'rail')
    name = tags.get('name', 'Voie ferrée')
    operator = tags.get('operator', 'Inconnu')
    gauge = tags.get('gauge', 'Standard')
    electrified = tags.get('electrified', 'Non')
    
    # Créer le contenu HTML du popup
    html = f"""
    <div style="font-family: Arial, sans-serif; width: 300px;">
        <h4 style="margin-top: 0; color: #333; border-bottom: 2px solid #333; padding-bottom: 5px;">
            Ligne Ferroviaire
        </h4>
        
        <div style="margin-bottom: 8px;"><strong>Nom:</strong> {name}</div>
        <div style="margin-bottom: 8px;"><strong>Type:</strong> {railway_type}</div>
        <div style="margin-bottom: 8px;"><strong>Opérateur:</strong> {operator}</div>
        <div style="margin-bottom: 8px;"><strong>Écartement:</strong> {gauge}</div>
        <div style="margin-bottom: 8px;"><strong>Électrifiée:</strong> {electrified}</div>
    </div>
    """
    
    return folium.Popup(html, max_width=300)

# Fonction pour traiter les données ferroviaires
def process_railway_data(data, group):
    """Traiter et ajouter les données ferroviaires à la carte."""
    if not data or 'elements' not in data:
        print("Aucune donnée ferroviaire trouvée.")
        return []
    
    railway_lines = []
    
    for element in data['elements']:
        if element['type'] == 'way' and 'geometry' in element:
            coords = [(node['lat'], node['lon']) for node in element['geometry']]
            
            # Créer un popup amélioré
            popup = create_enhanced_railway_popup(element)
            
            # Ajouter la ligne à la carte
            line = folium.PolyLine(
                coords,
                color="black",
                weight=3,
                opacity=0.8,
                popup=popup,
                smooth_factor=1.0
            )
            line.add_to(group)
            
            # Stocker les coordonnées pour une utilisation ultérieure
            railway_lines.append({
                'id': element['id'],
                'coords': coords,
                'tags': element.get('tags', {})
            })
    
    return railway_lines

# Fonction pour obtenir un graphe NetworkX du réseau ferroviaire
def get_railway_graph(north, south, east, west):
    """Obtenir un graphe NetworkX du réseau ferroviaire pour une zone donnée."""
    # Créer une clé de cache
    cache_key = f"{north},{south},{east},{west}"
    
    # Vérifier si le graphe est en cache
    if cache_key in GRAPH_CACHE:
        return GRAPH_CACHE[cache_key]
    
    try:
        print(f"Téléchargement du réseau ferroviaire pour la zone: {north},{south},{east},{west}")
        # Télécharger le réseau ferroviaire de la zone
        G = ox.graph_from_bbox(north, south, east, west, 
                              network_type='all', 
                              custom_filter='["railway"~"rail|tram|subway|light_rail"]')
        
        # Mettre en cache le graphe
        GRAPH_CACHE[cache_key] = G
        
        return G
    except Exception as e:
        print(f"Erreur lors de la récupération du graphe ferroviaire: {e}")
        return None

# Fonction pour trouver un itinéraire ferroviaire
def find_railway_route(from_lat, from_lon, to_lat, to_lon):
    """Trouver un itinéraire ferroviaire entre deux points en utilisant OSMnx et NetworkX."""
    # Créer une clé de cache
    cache_key = f"{from_lat},{from_lon}_{to_lat},{to_lon}"
    
    # Vérifier si l'itinéraire est en cache
    if cache_key in ROUTE_CACHE:
        return ROUTE_CACHE[cache_key]
    
    # Définir la zone englobant les deux points avec une marge
    north = max(from_lat, to_lat) + 0.1
    south = min(from_lat, to_lat) - 0.1
    east = max(from_lon, to_lon) + 0.1
    west = min(from_lon, to_lon) - 0.1
    
    # Obtenir le graphe ferroviaire
    G = get_railway_graph(north, south, east, west)
    
    if G is None or len(G.nodes) == 0:
        print("Aucun réseau ferroviaire trouvé dans la zone.")
        # Retourner une ligne droite simple
        route = [(from_lat, from_lon), (to_lat, to_lon)]
        ROUTE_CACHE[cache_key] = route
        return route
    
    try:
        # Trouver les nœuds les plus proches des points de départ et d'arrivée
        orig_node = ox.distance.nearest_nodes(G, from_lon, from_lat)
        dest_node = ox.distance.nearest_nodes(G, to_lon, to_lat)
        
        # Calculer le chemin le plus court
        route_nodes = nx.shortest_path(G, orig_node, dest_node, weight='length')
        
        # Extraire les coordonnées du chemin
        route_coords = []
        for node in route_nodes:
            y = G.nodes[node]['y']  # latitude
            x = G.nodes[node]['x']  # longitude
            route_coords.append((y, x))
        
        # Ajouter les points exacts de départ et d'arrivée
        route_coords = [(from_lat, from_lon)] + route_coords + [(to_lat, to_lon)]
        
        # Mettre en cache l'itinéraire
        ROUTE_CACHE[cache_key] = route_coords
        
        return route_coords
    except nx.NetworkXNoPath:
        print(f"Aucun chemin trouvé entre les nœuds {orig_node} et {dest_node}")
        # Retourner une ligne droite simple
        route = [(from_lat, from_lon), (to_lat, to_lon)]
        ROUTE_CACHE[cache_key] = route
        return route
    except Exception as e:
        print(f"Erreur lors du calcul de l'itinéraire: {e}")
        # Retourner une ligne droite simple
        route = [(from_lat, from_lon), (to_lat, to_lon)]
        ROUTE_CACHE[cache_key] = route
        return route

# Fonction pour créer une carte interactive avec les gares SNCF
def create_sncf_map_layer(stations):
    """Créer une couche pour les gares SNCF"""
    # Grouper par territoire pour le marquage
    territory_groups = {}
    for station in stations:
        # Déterminer le territoire de la gare
        territory = "Autre"
        name_lower = station["name"].lower()
        
        # Si c'est une gare explicitement demandée, la mettre dans un groupe spécial
        if station.get("is_additional", False):
            territory = "Gares supplémentaires"
        else:
            for t in TERRITORIES:
                if t in name_lower:
                    territory = t.capitalize()
                    break
        
        if territory not in territory_groups:
            territory_groups[territory] = []
        
        territory_groups[territory].append(station)
    
    # Créer un groupe pour les gares SNCF
    sncf_group = folium.FeatureGroup(name="🚂 Gares SNCF", show=True)
    
    # Créer des sous-groupes par territoire
    for territory, territory_stations in territory_groups.items():
        territory_group = folium.FeatureGroup(name=f"Gares SNCF: {territory}", show=True)
        
        for station in territory_stations:
            # Obtenir les départs pour cette gare
            departures = get_station_departures(station["id"])
            
            # Créer le contenu du popup
            update_time = datetime.now().strftime("%H:%M:%S")
            header_color = "#B22222"  # Rouge foncé
            
            popup_content = f"""
            <div style="font-family: Arial, sans-serif; width: 350px;">
                <h4 style="margin-top: 0; color: {header_color}; border-bottom: 2px solid {header_color}; padding-bottom: 5px;">
                    {station['name']}
                </h4>
                <div style="margin-bottom: 8px;"><strong>Territoire:</strong> {territory}</div>
                <div style="margin-bottom: 8px;"><strong>Coordonnées:</strong> {station['lat']:.5f}, {station['lon']:.5f}</div>
                
                <div style="margin-top: 10px;">
                    <h5 style="margin-top: 0; color: #333; border-bottom: 1px solid #ccc; padding-bottom: 3px;">
                        Prochains départs
                        <span style="float: right; font-size: 12px; color: #666;">
                            Mis à jour: {update_time}
                        </span>
                    </h5>
                    
                    <div style="max-height: 200px; overflow-y: auto; margin-top: 10px;">
                        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                            <thead>
                                <tr style="background-color: #f0f0f0;">
                                    <th style="padding: 5px; text-align: left; border-bottom: 1px solid #ddd;">Heure</th>
                                    <th style="padding: 5px; text-align: left; border-bottom: 1px solid #ddd;">Destination</th>
                                    <th style="padding: 5px; text-align: left; border-bottom: 1px solid #ddd;">Train</th>
                                    <th style="padding: 5px; text-align: left; border-bottom: 1px solid #ddd;">Voie</th>
                                </tr>
                            </thead>
                            <tbody>
            """
            
            if departures:
                for dep in departures[:5]:  # Afficher les 5 prochains départs
                    status_style = 'color: #cc0000;' if dep['status'] != 'on_time' else ''
                    popup_content += f"""
                                <tr style="{'background-color: #fff0f0;' if dep['status'] != 'on_time' else ''}">
                                    <td style="padding: 5px; border-bottom: 1px solid #ddd; {status_style}">
                                        {dep['time']}
                                    </td>
                                    <td style="padding: 5px; border-bottom: 1px solid #ddd;">
                                        {dep['direction']}
                                    </td>
                                    <td style="padding: 5px; border-bottom: 1px solid #ddd;">
                                        {dep['train_type']}
                                        <span style="font-size: 11px; color: #666;">{dep['number']}</span>
                                    </td>
                                    <td style="padding: 5px; border-bottom: 1px solid #ddd;">
                                        {dep['platform']}
                                    </td>
                                </tr>
                    """
                
                if len(departures) > 5:
                    popup_content += f"""
                                <tr>
                                    <td colspan="4" style="padding: 5px; text-align: center; color: #666; font-size: 12px;">
                                        ... et {len(departures) - 5} autres départs
                                    </td>
                                </tr>
                    """
            else:
                popup_content += """
                                <tr>
                                    <td colspan="4" style="padding: 10px; text-align: center; color: #666;">
                                        Aucun départ prévu
                                    </td>
                                </tr>
                """
            
            popup_content += """
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            """
            
            # Créer le marqueur avec une couleur différente pour les gares supplémentaires
            icon_color = 'red' if station.get("is_additional", False) else 'blue'
            
            folium.Marker(
                location=[station["lat"], station["lon"]],
                popup=folium.Popup(popup_content, max_width=350),
                icon=folium.Icon(color=icon_color, icon='train', prefix='fa'),
                tooltip=f"{station['name']} ({territory})"
            ).add_to(territory_group)
        
        territory_group.add_to(sncf_group)
    
    return sncf_group

# Fonction pour créer une couche pour les voies ferrées
def create_railway_layer():
    """Créer une couche pour les voies ferrées"""
    railway_group = folium.FeatureGroup(name="🛤️ Voies ferrées", show=True)
    
    # Récupérer et afficher les voies ferrées pour chaque zone
    all_railway_lines = []
    for zone_name, zone_coords in RAILWAY_ZONES.items():
        print(f"Récupération des données ferroviaires pour {zone_name}...")
        railway_data = fetch_railway_data(zone_name, zone_coords)
        if railway_data:
            railway_lines = process_railway_data(railway_data, railway_group)
            all_railway_lines.extend(railway_lines)
    
    return railway_group, all_railway_lines

# Fonction pour charger les données GTFS
def charger_donnees_gtfs(repertoire):
    donnees = {}
    
    # Charger les arrêts
    stops_path = os.path.join(repertoire, "stops.txt")
    if os.path.exists(stops_path):
        donnees["stops"] = pd.read_csv(stops_path)
    
    # Charger les lignes
    routes_path = os.path.join(repertoire, "routes.txt")
    if os.path.exists(routes_path):
        donnees["routes"] = pd.read_csv(routes_path)
        donnees["routes"]["route_id"] = donnees["routes"]["route_id"].astype(str)
    
    # Charger les formes (tracés)
    shapes_path = os.path.join(repertoire, "shapes.txt")
    if os.path.exists(shapes_path):
        donnees["shapes"] = pd.read_csv(shapes_path)
    
    # Charger les horaires
    stop_times_path = os.path.join(repertoire, "stop_times.txt")
    if os.path.exists(stop_times_path):
        donnees["stop_times"] = pd.read_csv(stop_times_path)
    
    # Charger les trajets
    trips_path = os.path.join(repertoire, "trips.txt")
    if os.path.exists(trips_path):
        donnees["trips"] = pd.read_csv(trips_path)
        donnees["trips"]["route_id"] = donnees["trips"]["route_id"].astype(str)
    
    return donnees

# Fonction pour récupérer les données de parking OSM
def get_parking_data(place_name):
    """Récupère les données de parking depuis OSM"""
    try:
        tags = {"amenity": "parking"}
        parking = ox.features_from_place(place_name, tags)
        return parking
    except Exception as e:
        print(f"Erreur lors de la récupération des parkings pour {place_name}: {e}")
        return None

# Fonction pour préparer les données des arrêts
def preparer_arrets(donnees, reseau):
    stops = donnees["stops"]
    arrets = []
    for _, arret in stops.iterrows():
        if pd.notna(arret['stop_lat']) and pd.notna(arret['stop_lon']):
            arrets.append({
                'id': arret['stop_id'],
                'nom': arret['stop_name'],
                'lat': arret['stop_lat'],
                'lon': arret['stop_lon'],
                'reseau': reseau
            })
    return arrets

# Fonction pour préparer les données des itinéraires
def preparer_itineraires(donnees, reseau):
    routes = donnees["routes"]
    shapes = donnees["shapes"]
    trips = donnees["trips"]
    
    itineraires = []
    
    for _, route in routes.iterrows():
        route_id = route['route_id']
        route_name = route['route_short_name'] if pd.notna(route['route_short_name']) else str(route_id)
        route_color = route['route_color'] if pd.notna(route['route_color']) else "808080"
        
        if route_color == "808080":
            route_color = "555555"
        else:
            if route_color.startswith("FF"):
                route_color = route_color.replace("FF", "E6")
            elif route_color.startswith("00"):
                route_color = route_color.replace("00", "00")
            elif route_color.startswith("FF00"):
                route_color = "CC00" + route_color[4:]
            elif len(route_color) == 6:
                route_color = "{:02X}{:02X}{:02X}".format(
                    max(0, int(route_color[0:2], 16) - 40),
                    max(0, int(route_color[2:4], 16) - 40),
                    max(0, int(route_color[4:6], 16) - 40)
                )
        
        route_trips = trips[trips['route_id'] == route_id]
        
        for _, trip in route_trips.iterrows():
            if pd.notna(trip['shape_id']):
                shape_id = trip['shape_id']
                shape_points = shapes[shapes['shape_id'] == shape_id].sort_values('shape_pt_sequence')
                
                if not shape_points.empty:
                    coords = [[float(row['shape_pt_lat']), float(row['shape_pt_lon'])] 
                              for _, row in shape_points.iterrows()]
                    
                    itineraires.append({
                        'route_id': route_id,
                        'route_name': route_name,
                        'color': f"#{route_color}",
                        'coords': coords,
                        'reseau': reseau
                    })
                    break
    return itineraires

# Fonction pour convertir l'heure au format HH:MM:SS en minutes depuis minuit
def heure_en_minutes(heure_str):
    if pd.isna(heure_str):
        return -1
    try:
        h, m, s = map(int, heure_str.split(':'))
        return h * 60 + m
    except:
        return -1

# Fonction pour préparer les horaires des arrêts avec filtrage en temps réel
def preparer_horaires(donnees):
    stop_times = donnees["stop_times"]
    trips = donnees["trips"]
    routes = donnees["routes"]
    
    stop_times['trip_id'] = stop_times['trip_id'].astype(str)
    trips['trip_id'] = trips['trip_id'].astype(str)
    trips['route_id'] = trips['route_id'].astype(str)
    routes['route_id'] = routes['route_id'].astype(str)
    
    merged = pd.merge(stop_times, trips, on='trip_id')
    merged = pd.merge(merged, routes, on='route_id')
    
    horaires_par_arret = defaultdict(list)
    
    for _, row in merged.iterrows():
        stop_id = row['stop_id']
        route_name = row['route_short_name'] if pd.notna(row['route_short_name']) else str(row['route_id'])
        route_color = row['route_color'] if pd.notna(row['route_color']) else "808080"
        
        if route_color == "808080":
            route_color = "555555"
        else:
            if route_color.startswith("FF"):
                route_color = route_color.replace("FF", "E6")
            elif route_color.startswith("00"):
                route_color = route_color.replace("00", "00")
            elif route_color.startswith("FF00"):
                route_color = "CC00" + route_color[4:]
            elif len(route_color) == 6:
                route_color = "{:02X}{:02X}{:02X}".format(
                    max(0, int(route_color[0:2], 16) - 40),
                    max(0, int(route_color[2:4], 16) - 40),
                    max(0, int(route_color[4:6], 16) - 40)
                )
        
        horaires_par_arret[stop_id].append({
            'ligne': route_name,
            'arrivee': row['arrival_time'],
            'depart': row['departure_time'],
            'minutes_arrivee': heure_en_minutes(row['arrival_time']),
            'minutes_depart': heure_en_minutes(row['departure_time']),
            'couleur': f"#{route_color}"
        })
    
    return dict(horaires_par_arret)

# Fonction pour récupérer les arrêts d'une ligne
def get_stops_for_route(route_id, trips_data, stop_times_data):
    """Récupère tous les arrêts pour une ligne donnée"""
    route_trips = trips_data[trips_data['route_id'] == route_id]
    stop_times_for_route = stop_times_data[stop_times_data['trip_id'].isin(route_trips['trip_id'])]
    return stop_times_for_route['stop_id'].unique()

# Fonction pour générer une couleur aléatoire mais cohérente pour chaque itinéraire FlixBus/FlixTrain
def get_route_color(route_id):
    # Utiliser le hash du route_id pour générer une couleur cohérente
    random.seed(hash(route_id))
    r = random.randint(0, 200)  # Éviter les couleurs trop claires
    g = random.randint(0, 200)
    b = random.randint(0, 200)
    return f'#{r:02x}{g:02x}{b:02x}'

# Fonction pour préparer les itinéraires FlixBus/FlixTrain
def preparer_itineraires_flixtrain_bus(donnees):
    if donnees is None:
        return None, None
    
    flixbus_routes_by_trip = {}
    flixtrain_routes_by_trip = {}
    
    # Traiter les voyages FlixBus
    if "flixbus_trip_routes" in donnees and "trip_to_shape" in donnees and "shapes" in donnees:
        for trip_id in donnees["flixbus_trip_routes"]:
            # Utiliser le shape si disponible
            if trip_id in donnees["trip_to_shape"] and donnees["trip_to_shape"][trip_id] in donnees["shapes"]:
                shape_id = donnees["trip_to_shape"][trip_id]
                shape_points = donnees["shapes"][shape_id]
                
                # Extraire les coordonnées du shape
                coordinates = [(point['lat'], point['lon']) for point in shape_points]
                
                if len(coordinates) >= 2:
                    color = get_route_color(trip_id)
                    flixbus_routes_by_trip[trip_id] = {
                        'type': 'shape',
                        'coordinates': coordinates,
                        'color': color,
                        'weight': 3,
                        'opacity': 0.7,
                        'tooltip': f"FlixBus - {trip_id}"
                    }
            
            # Sinon, utiliser les arrêts
            elif trip_id in donnees["flixbus_trip_routes"]:
                stops_list = donnees["flixbus_trip_routes"][trip_id]
                
                # Extraire les coordonnées des arrêts
                coordinates = [(stop['stop_lat'], stop['stop_lon']) for stop in stops_list]
                
                if len(coordinates) >= 2:
                    color = get_route_color(trip_id)
                    flixbus_routes_by_trip[trip_id] = {
                        'type': 'stops',
                        'coordinates': coordinates,
                        'color': color,
                        'weight': 3,
                        'opacity': 0.7,
                        'tooltip': f"FlixBus - {trip_id}"
                    }
    
    # Traiter les voyages FlixTrain
    if "flixtrain_trip_routes" in donnees and "trip_to_shape" in donnees and "shapes" in donnees:
        for trip_id in donnees["flixtrain_trip_routes"]:
            # Utiliser le shape si disponible
            if trip_id in donnees["trip_to_shape"] and donnees["trip_to_shape"][trip_id] in donnees["shapes"]:
                shape_id = donnees["trip_to_shape"][trip_id]
                shape_points = donnees["shapes"][shape_id]
                
                # Extraire les coordonnées du shape
                coordinates = [(point['lat'], point['lon']) for point in shape_points]
                
                if len(coordinates) >= 2:
                    flixtrain_routes_by_trip[trip_id] = {
                        'type': 'shape',
                        'coordinates': coordinates,
                        'color': 'red',
                        'weight': 4,
                        'opacity': 0.8,
                        'tooltip': f"FlixTrain - {trip_id}"
                    }
            
            # Sinon, utiliser les arrêts
            elif trip_id in donnees["flixtrain_trip_routes"]:
                stops_list = donnees["flixtrain_trip_routes"][trip_id]
                
                # Extraire les coordonnées des arrêts
                coordinates = [(stop['stop_lat'], stop['stop_lon']) for stop in stops_list]
                
                if len(coordinates) >= 2:
                    flixtrain_routes_by_trip[trip_id] = {
                        'type': 'stops',
                        'coordinates': coordinates,
                        'color': 'red',
                        'weight': 4,
                        'opacity': 0.8,
                        'tooltip': f"FlixTrain - {trip_id}"
                    }
    
    return flixbus_routes_by_trip, flixtrain_routes_by_trip

# Fonction pour formater les voyages d'une station avec des liens cliquables
def format_clickable_trips(stop_id, schedules, is_train=False):
    if stop_id not in schedules or not schedules[stop_id]:
        return "Aucun voyage disponible pour aujourd'hui."
    
    # Trier les horaires par heure de départ
    sorted_schedules = sorted(schedules[stop_id], key=lambda x: x['sort_key'])
    
    # Regrouper les horaires par ligne pour éviter les duplications
    grouped_trips = {}
    for schedule in sorted_schedules:
        trip_id = schedule['trip_id']
        route_id = schedule['route_id']
        route_name = f"{schedule['route_short_name']} - {schedule['route_name']}" if schedule['route_short_name'] else schedule['route_name']
        departure_time = schedule['departure_time_corr']
        
        # Clé unique pour éviter les duplications
        key = f"{route_id}_{departure_time}"
        
        if key not in grouped_trips:
            grouped_trips[key] = {
                'trip_id': trip_id,
                'route_name': route_name,
                'departure_time': departure_time
            }
    
    # Formater les voyages avec des liens cliquables
    trips_html = []
    for key, trip in grouped_trips.items():
        trip_type = "train" if is_train else "bus"
        trips_html.append(
            f'<div class="trip-item" onclick="showTrip(\'{trip["trip_id"]}\', \'{trip_type}\')">'
            f'<b>{trip["route_name"]}</b><br>'
            f'Départ: {trip["departure_time"]}'
            f'</div>'
        )
    
    # Ajouter un style CSS pour les éléments cliquables
    style = """
    <style>
    .trip-item {
        padding: 5px;
        margin-bottom: 5px;
        border: 1px solid #ddd;
        border-radius: 3px;
        cursor: pointer;
        background-color: #f9f9f9;
    }
    .trip-item:hover {
        background-color: #e9e9e9;
    }
    .trips-container {
        max-height: 400px;
        overflow-y: auto;
    }
    </style>
    """
    
    # Utiliser un conteneur avec défilement pour les arrêts avec beaucoup de voyages
    return style + "<div class='trips-container'>" + "</div>".join(trips_html) + "</div>"

# Fonction pour créer le contenu des popups pour les parkings
def creer_contenu_popup_parking(nom, adresse, lat, lon, reseau):
    contenu = f"""
    <div style="font-family: Arial, sans-serif; max-width: 300px;">
        <h3 style="color: #8B008B; margin-bottom: 5px; border-bottom: 2px solid #8B008B; padding-bottom: 5px;">Parking {reseau}</h3>
        <p style="margin-top: 8px; font-weight: bold; color: #8B008B;">
            {nom}
        </p>
        <p style="margin-top: 5px;"><strong>Adresse:</strong> {adresse}</p>
        <p style="margin-top: 5px;"><strong>Coordonnées:</strong> {lat:.5f}, {lon:.5f}</p>
        
        <div style="margin-top: 10px; font-size: 12px; color: #7f8c8d; text-align: right;">
            Mis à jour le {datetime.now().strftime("%d/%m/%Y")} à {datetime.now().strftime("%H:%M")}
        </div>
    </div>
    """
    return contenu

# Fonction pour créer le contenu des popups avec les horaires filtrés en temps réel
def creer_contenu_popup(arret_id, nom_arret, reseau):
    contenu = f"""
    <div style="font-family: Arial, sans-serif; max-width: 350px;">
        <h3 style="color: #2c3e50; margin-bottom: 5px; border-bottom: 2px solid #3498db; padding-bottom: 5px;">{nom_arret}</h3>
        <p style="margin-top: 8px; font-weight: bold; color: {'#1e88e5' if reseau == 'Montbéliard' else '#e53935'};">
            Réseau: {reseau}
        </p>
    """
    
    horaires = horaires_montbeliard.get(arret_id, []) if reseau == "Montbéliard" else horaires_belfort.get(arret_id, [])
    horaires_filtres = [h for h in horaires if h['minutes_depart'] >= heure_actuelle]
    horaires_filtres.sort(key=lambda x: x['minutes_depart'])
    
    if horaires_filtres:
        contenu += """
        <div style="margin-top: 10px;">
            <h4 style="color: #2c3e50; margin-bottom: 8px; border-bottom: 1px solid #bdc3c7; padding-bottom: 3px;">
                Prochains départs aujourd'hui
            </h4>
            <table style="width:100%; border-collapse: collapse; margin-top: 5px;">
                <tr style="background-color: #f2f2f2;">
                    <th style="padding: 8px; text-align: left; border-bottom: 2px solid #ddd;">Ligne</th>
                    <th style="padding: 8px; text-align: left; border-bottom: 2px solid #ddd;">Départ</th>
                    <th style="padding: 8px; text-align: left; border-bottom: 2px solid #ddd;">Arrivée</th>
                </tr>
        """
        
        for h in horaires_filtres[:10]:
            contenu += f"""
            <tr>
                <td style="padding: 6px; border-bottom: 1px solid #ddd; background-color: {h['couleur']}; color: white; font-weight: bold;">{h['ligne']}</td>
                <td style="padding: 6px; border-bottom: 1px solid #ddd;">{h['depart']}</td>
                <td style="padding: 6px; border-bottom: 1px solid #ddd;">{h['arrivee']}</td>
            </tr>
            """
        
        contenu += "</table></div>"
    else:
        contenu += """
        <div style="margin-top: 10px; padding: 10px; background-color: #f8f9fa; border-left: 4px solid #e74c3c; color: #7f8c8d;">
            <p>Aucun départ prévu pour aujourd'hui après l'heure actuelle.</p>
        </div>
        """
    
    contenu += """
    <div style="margin-top: 10px; font-size: 12px; color: #7f8c8d; text-align: right;">
        Mis à jour le {date} à {heure}
    </div>
    """.format(date=maintenant.strftime("%d/%m/%Y"), heure=maintenant.strftime("%H:%M"))
    
    contenu += "</div>"
    return contenu

# Fonction pour obtenir les données OSM
def get_osm_data(place_name, network_type):
    """Get OSM data with caching"""
    cache_file = f"cache_{place_name}_{network_type}.graphml"
    
    try:
        if os.path.exists(cache_file):
            return ox.load_graphml(cache_file)
        
        print(f"Downloading {place_name} {network_type} data...")
        graph = ox.graph_from_place(place_name, network_type=network_type)
        ox.save_graphml(graph, cache_file)
        return graph
    except Exception as e:
        print(f"Error getting OSM data for {place_name}: {e}")
        return None

# Fonction pour traiter les features OSM
def process_osm_features(graph, group, color, weight):
    """Process OSM features and add to map"""
    if graph is None:
        return
        
    gdf_edges = ox.graph_to_gdfs(graph, nodes=False, edges=True)
    
    for _, row in gdf_edges.iterrows():
        points = [(lat, lon) for lon, lat in row['geometry'].coords]
        folium.PolyLine(
            points,
            color=color,
            weight=weight,
            opacity=0.7,
            smooth_factor=1.0
        ).add_to(group)

# Créer une application Flask pour servir les données
app = Flask(__name__)

@app.route('/')
def index():
    return send_from_directory('.', 'carte_transports_temps_reel.html')

@app.route('/get_departures')
def get_departures_route():
    station_id = request.args.get('station_id')
    if not station_id:
        return jsonify([])
    
    departures = get_station_departures(station_id, limit=30)
    return jsonify(departures)

@app.route('/get_journey_details')
def get_journey_details_route():
    from_id = request.args.get('from_id')
    to_id = request.args.get('to_id')
    
    if not from_id or not to_id:
        return jsonify(None)
    
    # Obtenir les informations de départ via l'API SNCF
    now = datetime.now().strftime("%Y%m%dT%H%M%S")
    endpoint = f"coverage/{SNCF_COVERAGE}/journeys"
    params = {
        "from": from_id,
        "to": to_id,
        "datetime": now,
        "count": 1,
        "disable_geojson": True
    }
    
    response = make_sncf_api_request(endpoint, params)
    if not response or "journeys" not in response or not response["journeys"]:
        return jsonify(None)
    
    journey = response["journeys"][0]
    journey_details = {
        "duration": journey.get("duration", 0),
        "departure": format_api_datetime(journey.get("departure_date_time", "")),
        "arrival": format_api_datetime(journey.get("arrival_date_time", "")),
        "sections": [],
        "duration_formatted": format_duration(journey.get("duration", 0))
    }
    
    for section in journey.get("sections", []):
        if section.get("type") == "public_transport":
            display_info = section.get("display_informations", {})
            section_details = {
                "mode": display_info.get("commercial_mode", "Train"),
                "code": display_info.get("code", ""),
                "direction": display_info.get("direction", ""),
                "from": section.get("from", {}).get("name", ""),
                "to": section.get("to", {}).get("name", ""),
                "departure": format_api_datetime(section.get("departure_date_time", "")),
                "arrival": format_api_datetime(section.get("arrival_date_time", "")),
                "duration": format_duration(section.get("duration", 0))
            }
            journey_details["sections"].append(section_details)
    
    return jsonify(journey_details)

@app.route('/get_route')
def get_route():
    """Obtenir le tracé d'une route entre deux gares via OSMnx"""
    from_id = request.args.get('from_id')
    to_id = request.args.get('to_id')
    
    if not from_id or not to_id:
        return jsonify({"error": "Paramètres manquants"})
    
    # Charger toutes les gares
    stations = []
    if os.path.exists(CSV_FILE_PATH):
        stations = load_stations_from_csv(CSV_FILE_PATH)
    
    # Trouver les gares de départ et d'arrivée
    from_station = None
    to_station = None
    
    for station in stations:
        if station["id"] == from_id:
            from_station = station
        if station["id"] == to_id:
            to_station = station
        
        if from_station and to_station:
            break
    
    if not from_station or not to_station:
        return jsonify({"error": "Gares non trouvées"})
    
    # Récupérer l'itinéraire ferroviaire via OSMnx
    route_coords = find_railway_route(
        from_station["lat"], from_station["lon"],
        to_station["lat"], to_station["lon"]
    )
    
    return jsonify({"coordinates": route_coords})

@app.route('/find_destination_station')
def find_destination_station():
    from_id = request.args.get('from_id')
    destination_name = request.args.get('destination')
    
    if not from_id or not destination_name:
        return jsonify({"error": "Paramètres manquants"})
    
    # Charger toutes les gares
    stations = []
    if os.path.exists(CSV_FILE_PATH):
        stations = load_stations_from_csv(CSV_FILE_PATH)
    
    # Trouver la meilleure correspondance pour la destination
    destination_station = find_best_matching_station(stations, destination_name)
    
    if destination_station:
        return jsonify({"destination_id": destination_station["id"]})
    else:
        return jsonify({"error": "Destination non trouvée"})

def run_flask_app():
    app.run(host='0.0.0.0', port=5000)

def main():
    """Fonction principale"""
    global CSV_FILE_PATH, ALL_RAILWAY_LINES, horaires_montbeliard, horaires_belfort, heure_actuelle, maintenant
    
    print("Chargement des données...")
    
    # Vérifier si le fichier des gares SNCF existe dans le répertoire courant
    if not os.path.exists(CSV_FILE_PATH):
        # Essayer de trouver le fichier dans le répertoire d'upload
        upload_dir = "/home/ubuntu/upload"
        if os.path.exists(os.path.join(upload_dir, "gares-de-voyageurs.csv")):
            CSV_FILE_PATH = os.path.join(upload_dir, "gares-de-voyageurs.csv")
    
    # Charger les gares SNCF depuis le fichier CSV
    if os.path.exists(CSV_FILE_PATH):
        print(f"Chargement des gares SNCF depuis {CSV_FILE_PATH}...")
        stations = load_stations_from_csv(CSV_FILE_PATH)
    else:
        print("Aucun fichier de données SNCF trouvé!")
        stations = []
    
    print(f"{len(stations)} gares SNCF chargées.")
    
    # Charger les données pour Montbéliard et Belfort
    print("Chargement des données de Montbéliard...")
    montbeliard_data = charger_donnees_gtfs(montbeliard_dir)
    print("Chargement des données de Belfort...")
    belfort_data = charger_donnees_gtfs(belfort_dir)
    
    
    # Charger les données FlixBus/FlixTrain
    print("Chargement des données FlixBus/FlixTrain...")
    def charger_donnees_flixtrain_bus():
        donnees = {}
        
        try:
            # Charger les arrêts filtrés
            stops_filtered_path = os.path.join(horaires_dir, 'stops_filtered.csv')
            if os.path.exists(stops_filtered_path):
                donnees["stops_filtered"] = pd.read_csv(stops_filtered_path)
            
            # Charger les horaires FlixBus
            flixbus_schedules_path = os.path.join(horaires_dir, 'flixbus_schedules_today.json')
            if os.path.exists(flixbus_schedules_path):
                with open(flixbus_schedules_path, 'r') as f:
                    donnees["flixbus_schedules"] = json.load(f)
            
            # Charger les horaires FlixTrain
            flixtrain_schedules_path = os.path.join(horaires_dir, 'flixtrain_schedules_today.json')
            if os.path.exists(flixtrain_schedules_path):
                with open(flixtrain_schedules_path, 'r') as f:
                    donnees["flixtrain_schedules"] = json.load(f)
            
            # Charger les trajets FlixBus
            flixbus_trip_routes_path = os.path.join(horaires_dir, 'flixbus_trip_routes.json')
            if os.path.exists(flixbus_trip_routes_path):
                with open(flixbus_trip_routes_path, 'r') as f:
                    donnees["flixbus_trip_routes"] = json.load(f)
            
            # Charger les trajets FlixTrain
            flixtrain_trip_routes_path = os.path.join(horaires_dir, 'flixtrain_trip_routes.json')
            if os.path.exists(flixtrain_trip_routes_path):
                with open(flixtrain_trip_routes_path, 'r') as f:
                    donnees["flixtrain_trip_routes"] = json.load(f)
            
            # Charger les shapes
            shapes_path = os.path.join(horaires_dir, 'shapes.json')
            if os.path.exists(shapes_path):
                with open(shapes_path, 'r') as f:
                    donnees["shapes"] = json.load(f)
            
            # Charger le mapping trip_id -> shape_id
            trip_to_shape_path = os.path.join(horaires_dir, 'trip_to_shape.json')
            if os.path.exists(trip_to_shape_path):
                with open(trip_to_shape_path, 'r') as f:
                    donnees["trip_to_shape"] = json.load(f)
                    
        except Exception as e:
            print(f"Erreur lors du chargement des données FlixBus/FlixTrain: {e}")
            return None
        
        return donnees



    flixtrain_bus_data = charger_donnees_flixtrain_bus()
    
    # Récupérer les parkings pour Montbéliard et Belfort
    print("Récupération des données de parking...")
    montbeliard_parking = get_parking_data("Montbéliard, France")
    belfort_parking = get_parking_data("Belfort, France")
    
    # Préparer les données pour la carte
    print("Préparation des données pour la carte...")
    arrets_montbeliard = preparer_arrets(montbeliard_data, "Montbéliard")
    arrets_belfort = preparer_arrets(belfort_data, "Belfort")
    itineraires_montbeliard = preparer_itineraires(montbeliard_data, "Montbéliard")
    itineraires_belfort = preparer_itineraires(belfort_data, "Belfort")
    
    print("Préparation des horaires...")
    horaires_montbeliard = preparer_horaires(montbeliard_data)
    horaires_belfort = preparer_horaires(belfort_data)
    
    # Préparer les itinéraires FlixBus/FlixTrain
    print("Préparation des itinéraires FlixBus/FlixTrain...")
    flixbus_routes_by_trip, flixtrain_routes_by_trip = preparer_itineraires_flixtrain_bus(flixtrain_bus_data)
    
    # Obtenir l'heure actuelle
    maintenant = datetime.now()
    heure_actuelle = maintenant.hour * 60 + maintenant.minute


    carte = folium.Map(
    location=[47.6, 6.85],
    zoom_start=11,
    control_scale=True
    )

    # Ajouter les fonds de carte multiples
    #folium.TileLayer('openstreetmap', name='OpenStreetMap').add_to(carte)
    folium.TileLayer('CartoDB positron', name='CartoDB Positron', show=True).add_to(carte)

    # Ajouter les contrôles interactifs
    Fullscreen(
        position='topleft',
        title='Plein écran',
        title_cancel='Quitter le plein écran',
        force_separate_button=True
    ).add_to(carte)

    MousePosition(
    position='bottomright',
    separator=' | ',
    empty_string='',
    lng_first=True,
    num_digits=5,
    prefix='Coordonnées :'
    ).add_to(carte)

    # Ajouter un contrôle de mesure
    MeasureControl(
        position='bottomleft',
        primary_length_unit='kilometers',
        secondary_length_unit='miles',
        primary_area_unit='sqmeters',
        secondary_area_unit='acres'
    ).add_to(carte)
    
    # # Créer la carte centrée sur la région
    # print("Création de la carte interactive...")
    # carte = folium.Map(
    #     location=[47.6, 6.85],
    #     zoom_start=11,
    #     tiles='OpenStreetMap'
    # )
    
    # # Ajouter un contrôle de mesure
    # carte.add_child(MeasureControl())
    
    # Créer les groupes de couches par réseau
    groupe_montbeliard = folium.FeatureGroup(name="🚌 Bus Montbéliard", show=True)
    groupe_belfort = folium.FeatureGroup(name="🚌 Bus Belfort", show=True)
    groupe_parking_montbeliard = folium.FeatureGroup(name="🅿️ Parkings Montbéliard", show=False)
    groupe_parking_belfort = folium.FeatureGroup(name="🅿️ Parkings Belfort", show=False)
    groupe_routes_montbeliard = folium.FeatureGroup(name="🚗 Routes Montbéliard", show=False)
    groupe_routes_belfort = folium.FeatureGroup(name="🚗 Routes Belfort", show=False)
    groupe_pistes_montbeliard = folium.FeatureGroup(name="🚴Pistes cyclables Montbéliard", show=False)
    groupe_pistes_belfort = folium.FeatureGroup(name="🚴Pistes cyclables Belfort", show=False)
    
    # Ajouter les couches SNCF
    if stations:
        print("Ajout des gares SNCF...")
        sncf_group = create_sncf_map_layer(stations)
        sncf_group.add_to(carte)
        
        print("Ajout des voies ferrées...")
        railway_group, railway_lines = create_railway_layer()
        railway_group.add_to(carte)
        ALL_RAILWAY_LINES = railway_lines
    
    # Créer des clusters pour FlixBus et FlixTrain si les données sont disponibles
    if flixtrain_bus_data is not None and "stops_filtered" in flixtrain_bus_data:
        groupe_flixbus = folium.FeatureGroup(name="🚌 FlixBus", show=False)
        groupe_flixtrain = folium.FeatureGroup(name="🚂 FlixTrain", show=False)
        
        flixbus_cluster = MarkerCluster()
        flixtrain_cluster = MarkerCluster()
        
        print("Ajout des marqueurs FlixBus...")
        for _, stop in flixtrain_bus_data["stops_filtered"].iterrows():
            stop_id = stop['stop_id']
            
            # Vérifier si c'est un arrêt FlixBus
            if "flixbus_schedules" in flixtrain_bus_data and stop_id in flixtrain_bus_data["flixbus_schedules"] and flixtrain_bus_data["flixbus_schedules"][stop_id]:
                # Compter le nombre de voyages disponibles
                trip_count = len(set([schedule['trip_id'] for schedule in flixtrain_bus_data["flixbus_schedules"][stop_id]]))
                
                # Préparer les informations pour le popup
                popup_content = f"""
                <h4>{stop['stop_name']}</h4>
                <b>ID:</b> {stop_id}<br>
                <b>Coordonnées:</b> {stop['stop_lat']}, {stop['stop_lon']}<br>
                <h5>Voyages disponibles aujourd'hui ({trip_count}):</h5>
                <p>Cliquez sur un voyage pour voir son itinéraire</p>
                {format_clickable_trips(stop_id, flixtrain_bus_data["flixbus_schedules"])}
                """
                
                # Créer le popup
                popup = folium.Popup(popup_content, max_width=300)
                
                # Ajouter le marqueur au cluster FlixBus
                folium.Marker(
                    location=[stop['stop_lat'], stop['stop_lon']],
                    popup=popup,
                    tooltip=f"{stop['stop_name']} ({trip_count} voyages)",
                    icon=folium.Icon(color='green', icon='bus', prefix='fa')
                ).add_to(flixbus_cluster)
            
            # Vérifier si c'est un arrêt FlixTrain
            if "flixtrain_schedules" in flixtrain_bus_data and stop_id in flixtrain_bus_data["flixtrain_schedules"] and flixtrain_bus_data["flixtrain_schedules"][stop_id]:
                # Compter le nombre de voyages disponibles
                trip_count = len(set([schedule['trip_id'] for schedule in flixtrain_bus_data["flixtrain_schedules"][stop_id]]))
                
                # Préparer les informations pour le popup
                popup_content = f"""
                <h4>{stop['stop_name']}</h4>
                <b>ID:</b> {stop_id}<br>
                <b>Coordonnées:</b> {stop['stop_lat']}, {stop['stop_lon']}<br>
                <h5>Voyages disponibles aujourd'hui ({trip_count}):</h5>
                <p>Cliquez sur un voyage pour voir son itinéraire</p>
                {format_clickable_trips(stop_id, flixtrain_bus_data["flixtrain_schedules"], is_train=True)}
                """
                
                # Créer le popup
                popup = folium.Popup(popup_content, max_width=300)
                
                # Ajouter le marqueur au cluster FlixTrain
                folium.Marker(
                    location=[stop['stop_lat'], stop['stop_lon']],
                    popup=popup,
                    tooltip=f"{stop['stop_name']} ({trip_count} voyages)",
                    icon=folium.Icon(color='red', icon='train', prefix='fa')
                ).add_to(flixtrain_cluster)
        
        flixbus_cluster.add_to(groupe_flixbus)
        flixtrain_cluster.add_to(groupe_flixtrain)
        groupe_flixbus.add_to(carte)
        groupe_flixtrain.add_to(carte)
    
    # Ajouter les parkings de Montbéliard
    if montbeliard_parking is not None and not montbeliard_parking.empty:
        print("Ajout des parkings de Montbéliard...")
        for _, parking in montbeliard_parking.iterrows():
            if parking.geometry and parking.geometry.centroid:
                nom = parking.get('name', 'Parking inconnu')
                adresse = parking.get('addr:street', 'Adresse inconnue')
                coords = [parking.geometry.centroid.y, parking.geometry.centroid.x]
                
                popup_content = creer_contenu_popup_parking(
                    nom, 
                    adresse, 
                    coords[0], 
                    coords[1], 
                    "Montbéliard"
                )
                
                folium.Marker(
                    location=coords,
                    popup=folium.Popup(popup_content, max_width=300),
                    icon=folium.Icon(color='purple', icon='car', prefix='fa'),
                    tooltip=f"Parking: {nom}"
                ).add_to(groupe_parking_montbeliard)
    
    # Ajouter les parkings de Belfort
    if belfort_parking is not None and not belfort_parking.empty:
        print("Ajout des parkings de Belfort...")
        for _, parking in belfort_parking.iterrows():
            if parking.geometry and parking.geometry.centroid:
                nom = parking.get('name', 'Parking inconnu')
                adresse = parking.get('addr:street', 'Adresse inconnue')
                coords = [parking.geometry.centroid.y, parking.geometry.centroid.x]
                
                popup_content = creer_contenu_popup_parking(
                    nom, 
                    adresse, 
                    coords[0], 
                    coords[1], 
                    "Belfort"
                )
                
                folium.Marker(
                    location=coords,
                    popup=folium.Popup(popup_content, max_width=300),
                    icon=folium.Icon(color='darkpurple', icon='car', prefix='fa'),
                    tooltip=f"Parking: {nom}"
                ).add_to(groupe_parking_belfort)
    
    # Ajouter les éléments de Montbéliard
    print("Ajout des éléments de Montbéliard...")
    cluster_montbeliard = MarkerCluster()
    for arret in arrets_montbeliard:
        popup_content = creer_contenu_popup(arret['id'], arret['nom'], arret['reseau'])
        folium.Marker(
            location=[arret['lat'], arret['lon']],
            popup=folium.Popup(popup_content, max_width=400),
            tooltip=f"{arret['nom']} (Montbéliard)",
            icon=folium.Icon(color='blue', icon='bus', prefix='fa')
        ).add_to(cluster_montbeliard)
    cluster_montbeliard.add_to(groupe_montbeliard)
    
    for itineraire in itineraires_montbeliard:
        # Récupérer les arrêts pour cette ligne
        stops_for_route = get_stops_for_route(
            itineraire['route_id'], 
            montbeliard_data['trips'], 
            montbeliard_data['stop_times']
        )
        
        # Créer le contenu du popup
        popup_content = f"""
        <div style="font-family: Arial, sans-serif; max-width: 300px;">
            <h3 style="color: {itineraire['color']}; margin-bottom: 5px;">
                Ligne {itineraire['route_name']}
            </h3>
            <p style="margin-top: 5px;"><strong>Réseau:</strong> Montbéliard</p>
            <div style="max-height: 200px; overflow-y: auto;">
                <h4 style="margin-bottom: 5px;">Arrêts:</h4>
                <ul style="padding-left: 15px; margin-top: 5px;">
        """
        
        # Ajouter chaque arrêt à la liste
        for stop_id in stops_for_route:
            stop_info = next((s for s in arrets_montbeliard if s['id'] == stop_id), None)
            if stop_info:
                popup_content += f"<li>{stop_info['nom']}</li>"
        
        popup_content += """
                </ul>
            </div>
        </div>
        """
        
        # Créer la ligne avec le popup
        folium.PolyLine(
            locations=itineraire['coords'],
            color=itineraire['color'],
            weight=4,
            opacity=0.9,
            tooltip=f"Ligne {itineraire['route_name']} (Montbéliard)",
            popup=folium.Popup(popup_content, max_width=300)
        ).add_to(groupe_montbeliard)
    
    # Ajouter les éléments de Belfort
    print("Ajout des éléments de Belfort...")
    cluster_belfort = MarkerCluster()
    for arret in arrets_belfort:
        popup_content = creer_contenu_popup(arret['id'], arret['nom'], arret['reseau'])
        folium.Marker(
            location=[arret['lat'], arret['lon']],
            popup=folium.Popup(popup_content, max_width=400),
            tooltip=f"{arret['nom']} (Belfort)",
            icon=folium.Icon(color='red', icon='bus', prefix='fa')
        ).add_to(cluster_belfort)
    cluster_belfort.add_to(groupe_belfort)
    
    for itineraire in itineraires_belfort:
        stops_for_route = get_stops_for_route(
            itineraire['route_id'], 
            belfort_data['trips'], 
            belfort_data['stop_times']
        )
        
        popup_content = f"""
        <div style="font-family: Arial, sans-serif; max-width: 300px;">
            <h3 style="color: {itineraire['color']}; margin-bottom: 5px;">
                Ligne {itineraire['route_name']}
            </h3>
            <p style="margin-top: 5px;"><strong>Réseau:</strong> Belfort</p>
            <div style="max-height: 200px; overflow-y: auto;">
                <h4 style="margin-bottom: 5px;">Arrêts:</h4>
                <ul style="padding-left: 15px; margin-top: 5px;">
        """
        
        for stop_id in stops_for_route:
            stop_info = next((s for s in arrets_belfort if s['id'] == stop_id), None)
            if stop_info:
                popup_content += f"<li>{stop_info['nom']}</li>"
        
        popup_content += """
                </ul>
            </div>
        </div>
        """
        
        folium.PolyLine(
            locations=itineraire['coords'],
            color=itineraire['color'],
            weight=4,
            opacity=0.9,
            tooltip=f"Ligne {itineraire['route_name']} (Belfort)",
            popup=folium.Popup(popup_content, max_width=300)
        ).add_to(groupe_belfort)
    
    # Récupérer les données OSM pour les pistes cyclables
    print("Récupération des données des routes...")
    montbeliard_roads = get_osm_data("Pays de Montbéliard Agglomération, France", 'all')
    belfort_roads = get_osm_data("Grand Belfort, France", 'all')
    print("Récupération des données de pistes cyclables...")
    montbeliard_bike = get_osm_data("Pays de Montbéliard Agglomération, France", 'bike')
    belfort_bike = get_osm_data("Grand Belfort, France", 'bike')
    
    # Traiter les données des routes
    if montbeliard_roads:
        process_osm_features(montbeliard_roads, groupe_routes_montbeliard, "blue", 1)
    if belfort_roads:
        process_osm_features(belfort_roads, groupe_routes_belfort, "red", 1)
    
    # Traiter les données des cyclables
    if montbeliard_bike:
        process_osm_features(montbeliard_bike, groupe_pistes_montbeliard, "green", 2)
    if belfort_bike:
        process_osm_features(belfort_bike, groupe_pistes_belfort, "orange", 2)
    
    # Ajouter les groupes à la carte
    groupe_montbeliard.add_to(carte)
    groupe_belfort.add_to(carte)
    groupe_parking_montbeliard.add_to(carte)
    groupe_parking_belfort.add_to(carte)
    groupe_routes_montbeliard.add_to(carte)
    groupe_routes_belfort.add_to(carte)
    groupe_pistes_montbeliard.add_to(carte)
    groupe_pistes_belfort.add_to(carte)

        # Ajout du FeatureGroup pour l'agrégation des données de transport
    print("Création du groupe d'agrégation des données de transport...")

    # Fonction pour créer le contenu du popup d'un cluster avec bouton d'export JSON
    def create_cluster_popup_content(cluster_id, cluster_name, transports):
        """Crée le contenu HTML du popup pour un cluster de transport"""
        # Préparer les données pour l'export JSON
        cluster_data = {
            "cluster_id": cluster_id,
            "cluster_name": cluster_name,
            "total_transports": sum(len(t["departures"]) for t in transports),
            "transports": transports
        }

        safe_json = html.escape(json.dumps(cluster_data).replace("\\", "\\\\").replace("'", "\\'"))

        
        # Créer le contenu HTML du popup
        popup_content = f"""
        <div style="font-family: Arial, sans-serif; width: 400px;">
            <h3 style="margin-top: 0; color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 5px;">
                {cluster_name}
            </h3>
            <p style="margin-top: 8px; font-weight: bold; color: #2c3e50;">
                Total: {sum(len(t["departures"]) for t in transports)} transports disponibles
            </p>
            
            <div style="max-height: 300px; overflow-y: auto; margin-top: 10px;">
        """
        
        # Ajouter les informations pour chaque type de transport
        for transport in transports:
            transport_type = transport["type"]
            transport_color = transport["color"]
            departures = transport["departures"]
            
            if departures:
                popup_content += f"""
                <div style="margin-top: 15px; border-left: 4px solid {transport_color}; padding-left: 10px;">
                    <h4 style="margin: 0 0 8px 0; color: {transport_color};">
                        {transport_type} ({len(departures)})
                    </h4>
                    <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                        <thead>
                            <tr style="background-color: #f2f2f2;">
                                <th style="padding: 5px; text-align: left; border-bottom: 1px solid #ddd;">Ligne</th>
                                <th style="padding: 5px; text-align: left; border-bottom: 1px solid #ddd;">Départ</th>
                                <th style="padding: 5px; text-align: left; border-bottom: 1px solid #ddd;">Destination</th>
                            </tr>
                        </thead>
                        <tbody>
                """
                
                for departure in departures:
                    popup_content += f"""
                    <tr>
                        <td style="padding: 5px; border-bottom: 1px solid #ddd; background-color: {departure.get('color', transport_color)}; color: white; font-weight: bold;">
                            {departure.get('line', 'N/A')}
                        </td>
                        <td style="padding: 5px; border-bottom: 1px solid #ddd;">
                            {departure.get('time', 'N/A')}
                        </td>
                        <td style="padding: 5px; border-bottom: 1px solid #ddd;">
                            {departure.get('direction', 'N/A')}
                        </td>
                    </tr>
                    """
                
                popup_content += """
                        </tbody>
                    </table>
                </div>
                """
        
        # Ajouter le bouton d'export JSON avec JavaScript
        popup_content += f"""
            </div>
            
            <div style="margin-top: 15px; text-align: center;">
                <button onclick="exportClusterData('{cluster_id}', '{safe_json}')" style="
                    background-color: #3498db;
                    color: white;
                    padding: 8px 15px;
                    border: none;
                    border-radius: 4px;
                    font-weight: bold;
                    cursor: pointer;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                ">
                    Exporter en JSON
                </button>
            </div>
            
            <div style="margin-top: 10px; font-size: 12px; color: #7f8c8d; text-align: right;">
                Mis à jour le {datetime.now().strftime("%d/%m/%Y")} à {datetime.now().strftime("%H:%M")}
            </div>
        </div>
        """
        
        return popup_content

    # Fonction pour créer un marqueur de cluster avec le nombre total de transports
    def create_cluster_marker(lat, lon, cluster_id, cluster_name, transports):
        """Crée un marqueur pour un cluster de transport avec le nombre total affiché"""
        total_transports = sum(len(t["departures"]) for t in transports)
        
        # Créer le contenu du popup
        popup_content = create_cluster_popup_content(cluster_id, cluster_name, transports)
        
        # Créer un marqueur personnalisé avec le nombre total au centre
        icon_html = f"""
        <div style="
            background-color: #3498db;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
        ">
            {total_transports}
        </div>
        """
        
        icon = folium.DivIcon(
            html=icon_html,
            icon_size=(40, 40),
            icon_anchor=(20, 20)
        )
        
        # Créer le marqueur avec le popup
        marker = folium.Marker(
            location=[lat, lon],
            icon=icon,
            popup=folium.Popup(popup_content, max_width=400),
            tooltip=f"Cluster {cluster_name}: {total_transports} transports"
        )
        
        return marker

    # Fonction pour collecter les données de transport autour d'un point
    def collect_transport_data_around_point(lat, lon, radius=500):
        """Collecte les données de transport dans un rayon autour d'un point"""
        transports = []
        
        # Collecter les données des bus Montbéliard
        montbeliard_bus = {
            "type": "Bus Montbéliard",
            "color": "#1e88e5",
            "departures": []
        }
        
        for arret in arrets_montbeliard:
            # Calculer la distance entre le point et l'arrêt
            arret_lat, arret_lon = arret['lat'], arret['lon']
            distance = ((lat - arret_lat) ** 2 + (lon - arret_lon) ** 2) ** 0.5 * 111000  # Conversion approximative en mètres
            
            if distance <= radius:
                # Récupérer les horaires pour cet arrêt
                horaires = horaires_montbeliard.get(arret['id'], [])
                horaires_filtres = [h for h in horaires if h['minutes_depart'] >= heure_actuelle]
                horaires_filtres.sort(key=lambda x: x['minutes_depart'])
                
                for h in horaires_filtres[:5]:  # Limiter aux 5 prochains départs
                    montbeliard_bus["departures"].append({
                        "line": h['ligne'],
                        "time": h['depart'],
                        "direction": "Destination",  # Information non disponible dans les données
                        "color": h['couleur']
                    })
        
        if montbeliard_bus["departures"]:
            transports.append(montbeliard_bus)
        
        # Collecter les données des bus Belfort
        belfort_bus = {
            "type": "Bus Belfort",
            "color": "#e53935",
            "departures": []
        }
        
        for arret in arrets_belfort:
            arret_lat, arret_lon = arret['lat'], arret['lon']
            distance = ((lat - arret_lat) ** 2 + (lon - arret_lon) ** 2) ** 0.5 * 111000
            
            if distance <= radius:
                horaires = horaires_belfort.get(arret['id'], [])
                horaires_filtres = [h for h in horaires if h['minutes_depart'] >= heure_actuelle]
                horaires_filtres.sort(key=lambda x: x['minutes_depart'])
                
                for h in horaires_filtres[:5]:
                    belfort_bus["departures"].append({
                        "line": h['ligne'],
                        "time": h['depart'],
                        "direction": "Destination",
                        "color": h['couleur']
                    })
        
        if belfort_bus["departures"]:
            transports.append(belfort_bus)
        
        # Collecter les données des trains SNCF
        sncf_trains = {
            "type": "Trains SNCF",
            "color": "#B22222",
            "departures": []
        }
        
        for station in stations:
            station_lat, station_lon = station['lat'], station['lon']
            distance = ((lat - station_lat) ** 2 + (lon - station_lon) ** 2) ** 0.5 * 111000
            
            if distance <= radius:
                # Obtenir les départs pour cette gare
                departures = get_station_departures(station["id"])
                
                for dep in departures:
                    sncf_trains["departures"].append({
                        "line": f"{dep['train_type']} {dep['number']}",
                        "time": dep['time'],
                        "direction": dep['direction'],
                        "color": "#B22222"
                    })
        
        if sncf_trains["departures"]:
            transports.append(sncf_trains)
        
        # Collecter les données FlixBus si disponibles
        if 'flixbus_schedules' in flixtrain_bus_data:
            flixbus = {
                "type": "FlixBus",
                "color": "#4CAF50",
                "departures": []
            }
            
            for stop_id, schedules in flixtrain_bus_data['flixbus_schedules'].items():
                # Trouver les coordonnées de l'arrêt
                stop_info = None
                if 'stops_filtered' in flixtrain_bus_data:
                    stop_info = flixtrain_bus_data['stops_filtered'][flixtrain_bus_data['stops_filtered']['stop_id'] == stop_id]
                
                if stop_info is not None and not stop_info.empty:
                    stop_lat = stop_info['stop_lat'].values[0]
                    stop_lon = stop_info['stop_lon'].values[0]
                    distance = ((lat - stop_lat) ** 2 + (lon - stop_lon) ** 2) ** 0.5 * 111000
                    
                    if distance <= radius:
                        for schedule in schedules:
                            departure_time = schedule.get('departure_time', '')
                            if departure_time:
                                try:
                                    dt = datetime.strptime(departure_time, "%H:%M:%S")
                                    time_obj = dt.time()
                                    current_time = datetime.now().time()
                                    
                                    if time_obj >= current_time:
                                        flixbus["departures"].append({
                                            "line": f"FlixBus {schedule.get('route_id', '')}",
                                            "time": departure_time.split(':')[0] + ':' + departure_time.split(':')[1],
                                            "direction": schedule.get('headsign', 'Inconnu'),
                                            "color": "#4CAF50"
                                        })
                                except ValueError:
                                    pass
            
            if flixbus["departures"]:
                transports.append(flixbus)
        
        # Collecter les données FlixTrain si disponibles
        if 'flixtrain_schedules' in flixtrain_bus_data:
            flixtrain = {
                "type": "FlixTrain",
                "color": "#FF5722",
                "departures": []
            }
            
            for stop_id, schedules in flixtrain_bus_data['flixtrain_schedules'].items():
                # Trouver les coordonnées de l'arrêt
                stop_info = None
                if 'stops_filtered' in flixtrain_bus_data:
                    stop_info = flixtrain_bus_data['stops_filtered'][flixtrain_bus_data['stops_filtered']['stop_id'] == stop_id]
                
                if stop_info is not None and not stop_info.empty:
                    stop_lat = stop_info['stop_lat'].values[0]
                    stop_lon = stop_info['stop_lon'].values[0]
                    distance = ((lat - stop_lat) ** 2 + (lon - stop_lon) ** 2) ** 0.5 * 111000
                    
                    if distance <= radius:
                        for schedule in schedules:
                            departure_time = schedule.get('departure_time', '')
                            if departure_time:
                                try:
                                    dt = datetime.strptime(departure_time, "%H:%M:%S")
                                    time_obj = dt.time()
                                    current_time = datetime.now().time()
                                    
                                    if time_obj >= current_time:
                                        flixtrain["departures"].append({
                                            "line": f"FlixTrain {schedule.get('route_id', '')}",
                                            "time": departure_time.split(':')[0] + ':' + departure_time.split(':')[1],
                                            "direction": schedule.get('headsign', 'Inconnu'),
                                            "color": "#FF5722"
                                        })
                                except ValueError:
                                    pass
            
            if flixtrain["departures"]:
                transports.append(flixtrain)
        
        return transports

    # Définir les points d'intérêt pour les clusters dans les zones définies
    # Ces points sont basés sur les principales gares et centres de transport
    clusters_points = [
        # Montbéliard
        {"lat": 47.5103, "lon": 6.7998, "id": "montbeliard_gare", "name": "Gare de Montbéliard"},
        {"lat": 47.5067, "lon": 6.7989, "id": "montbeliard_centre", "name": "Centre-ville Montbéliard"},
        {"lat": 47.4853, "lon": 6.8361, "id": "sochaux", "name": "Sochaux"},
        
        # Belfort
        {"lat": 47.6333, "lon": 6.8500, "id": "belfort_gare", "name": "Gare de Belfort"},
        {"lat": 47.6392, "lon": 6.8628, "id": "belfort_centre", "name": "Centre-ville Belfort"},
        {"lat": 47.6158, "lon": 6.8744, "id": "belfort_techn", "name": "Belfort Technopôle"},
        
        # Mulhouse
        {"lat": 47.7421, "lon": 7.3422, "id": "mulhouse_gare", "name": "Gare de Mulhouse"},
        
        # Strasbourg
        {"lat": 48.5850, "lon": 7.7356, "id": "strasbourg_gare", "name": "Gare de Strasbourg"},
        
        # Aéroport Bâle-Mulhouse
        {"lat": 47.5896, "lon": 7.5299, "id": "bale_mulhouse_airport", "name": "Aéroport Bâle-Mulhouse"}
    ]

    # Créer le groupe d'agrégation des données
    groupe_agregation = folium.FeatureGroup(name="📦Agrégation des données", show=True)

    # Ajouter les clusters pour chaque point d'intérêt
    for point in clusters_points:
        # Collecter les données de transport autour du point
        transports = collect_transport_data_around_point(point["lat"], point["lon"], radius=800)
        
        # Ne créer un cluster que s'il y a des transports disponibles
        if transports and sum(len(t["departures"]) for t in transports) > 0:
            # Créer le marqueur de cluster
            marker = create_cluster_marker(
                point["lat"], 
                point["lon"], 
                point["id"], 
                point["name"], 
                transports
            )
            
            # Ajouter le marqueur au groupe
            marker.add_to(groupe_agregation)

    # Ajouter le groupe à la carte
    groupe_agregation.add_to(carte)

    # Trouver la légende parmi les enfants HTML
    legende_html = None
    for child_key, child in carte.get_root().html._children.items():
        if 'Légende' in str(child):
            legende_html = child
            break

    # Si la légende est trouvée, la modifier
    if legende_html:
        legende_html_str = str(legende_html)
        
        # Ajouter l'entrée pour les clusters d'agrégation à la légende
        nouvelle_entree = '''
                <div style="display: flex; align-items: center; margin-bottom: 5px;">
                    <div style="background-color: #3498db; width: 16px; height: 16px; border-radius: 50%; margin-right: 8px;"></div>
                    <span style="font-family: Arial, sans-serif; font-size: 13px;">Clusters de transport</span>
                </div>
        '''
        
        # Insérer la nouvelle entrée avant la dernière div (mise à jour)
        position_insertion = legende_html_str.rfind('<div style="font-family: Arial, sans-serif; font-size: 11px;')
        if position_insertion != -1:
            nouvelle_legende = legende_html_str[:position_insertion] + nouvelle_entree + legende_html_str[position_insertion:]
            
            # Remplacer l'ancienne légende par la nouvelle
            for child_key, child in carte.get_root().html._children.items():
                if child == legende_html:
                    carte.get_root().html._children[child_key] = folium.Element(nouvelle_legende)
                    break

    # Ajouter le script JavaScript pour l'export JSON
    export_script = """
    <script>
    // Version améliorée avec gestion du contexte iframe
    function exportClusterData(clusterId, dataStr) {
        try {
            // Récupérer le bon document
            const targetDoc = document.querySelector('iframe.leaflet-html-embed')?.contentDocument || document;
            
            // Parser les données si nécessaire
            const data = typeof dataStr === 'string' ? JSON.parse(dataStr) : dataStr;
            
            // Créer le blob
            const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
            const url = URL.createObjectURL(blob);
            
            // Créer et déclencher le téléchargement
            const a = targetDoc.createElement('a');
            a.href = url;
            a.download = `cluster_${clusterId}_${new Date().toISOString()}.json`;
            targetDoc.body.appendChild(a);
            a.click();
            
            // Nettoyage
            setTimeout(() => {
                targetDoc.body.removeChild(a);
                URL.revokeObjectURL(url);
            }, 100);
        } catch (error) {
            console.error('Export error:', error);
            alert(`Erreur lors de l'export: ${error.message}`);
        }
    }
    </script>
    """
    carte.get_root().html.add_child(folium.Element(export_script))

    print("Groupe d'agrégation des données de transport ajouté avec succès!")

    
    # Ajouter le contrôle de couches
    folium.LayerControl(collapsed=False).add_to(carte)
    
    # Ajouter une légende pour les réseaux
    legende_html = '''
    <div style="position: fixed; 
                bottom: 50px; left: 50px; width: 220px;
                border:2px solid grey; z-index:9999; 
                background-color:white; padding: 10px;
                border-radius: 5px; box-shadow: 0 0 15px rgba(0,0,0,0.2);">
        <div style="font-family: Arial, sans-serif; font-size: 14px; font-weight: bold; margin-bottom: 10px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 5px;">
            Légende
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <i class="fa fa-bus" style="color:blue; margin-right: 8px;"></i>
            <span style="font-family: Arial, sans-serif; font-size: 13px;">Bus Montbéliard</span>
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <i class="fa fa-bus" style="color:red; margin-right: 8px;"></i>
            <span style="font-family: Arial, sans-serif; font-size: 13px;">Bus Belfort</span>
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <i class="fa fa-bus" style="color:green; margin-right: 8px;"></i>
            <span style="font-family: Arial, sans-serif; font-size: 13px;">FlixBus</span>
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <i class="fa fa-train" style="color:red; margin-right: 8px;"></i>
            <span style="font-family: Arial, sans-serif; font-size: 13px;">FlixTrain</span>
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <i class="fa fa-train" style="color:blue; margin-right: 8px;"></i>
            <span style="font-family: Arial, sans-serif; font-size: 13px;">Gares SNCF</span>
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <i class="fa fa-car" style="color:purple; margin-right: 8px;"></i>
            <span style="font-family: Arial, sans-serif; font-size: 13px;">Parkings Montbéliard</span>
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <i class="fa fa-car" style="color:darkpurple; margin-right: 8px;"></i>
            <span style="font-family: Arial, sans-serif; font-size: 13px;">Parkings Belfort</span>
        </div>
        <div style="font-family: Arial, sans-serif; font-size: 11px; color: #7f8c8d; margin-top: 8px; text-align: center;">
            Mis à jour le ''' + maintenant.strftime("%d/%m/%Y") + ' à ' + maintenant.strftime("%H:%M") + '''
        </div>
    </div>
    '''
    carte.get_root().html.add_child(folium.Element(legende_html))
    
    # Ajouter un titre à la carte
    titre_html = '''
    <div style="position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            width: 400px;
            background-color: rgba(243, 255, 255, 0.8);
            border-radius: 5px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            z-index: 9999;
            padding: 10px;
            text-align: center;">
        <h3 style="font-family: Arial, sans-serif; margin: 0; color: #2c3e50;">
            Web API Dynamic Carpooling
        </h3>
    </div>
    '''
    carte.get_root().html.add_child(folium.Element(titre_html))
    
    # Ajouter le JavaScript pour gérer l'affichage dynamique des itinéraires FlixBus/FlixTrain
    if flixbus_routes_by_trip is not None and flixtrain_routes_by_trip is not None:
        js_code = '''
        // Initialiser les variables globales
        var busRoutes = {};
        var trainRoutes = {};
        var routesLayer = null;
        var map = null;
    
        // Fonction pour initialiser la carte
        function initMap(mapObj) {
            map = mapObj;
            routesLayer = L.featureGroup().addTo(map);
            routesLayer.clearLayers();
        }
    
        // Fonction pour afficher l'itinéraire d'un voyage
        function showTrip(tripId, type) {
            console.log("showTrip called for tripId: " + tripId + ", type: " + type);
            
            // Effacer les itinéraires précédents
            routesLayer.clearLayers();
            
            // Sélectionner l'itinéraire approprié
            var route = type === 'train' ? trainRoutes[tripId] : busRoutes[tripId];
            
            if (route) {
                console.log("Found route for this trip");
                
                // Ajouter l'itinéraire à la couche
                var polyline = L.polyline(
                    route.coordinates, 
                    {
                        color: route.color,
                        weight: route.weight,
                        opacity: route.opacity
                    }
                ).addTo(routesLayer);
                
                if (route.tooltip) {
                    polyline.bindTooltip(route.tooltip);
                }
                
                // Si c'est un itinéraire basé sur les arrêts (et non sur un shape), utiliser une ligne pointillée
                if (route.type === 'stops') {
                    polyline.setStyle({dashArray: '5, 10'});
                }
                
                // S'assurer que la couche est visible
                map.addLayer(routesLayer);
                
                // Ajuster la vue pour voir tout l'itinéraire
                try {
                    map.fitBounds(routesLayer.getBounds(), {padding: [50, 50]});
                } catch (e) {
                    console.log("Error fitting bounds: " + e);
                }
            } else {
                console.log("No route found for this trip");
                alert("Aucun itinéraire disponible pour ce voyage");
            }
        }
        '''
    
        # Ajouter le JavaScript à la carte
        carte.get_root().html.add_child(folium.Element(f'''
        <script>
        {js_code}
    
        // Données des itinéraires FlixBus
        busRoutes = {json.dumps(flixbus_routes_by_trip) if flixbus_routes_by_trip is not None else {}};
    
        // Données des itinéraires FlixTrain
        trainRoutes = {json.dumps(flixtrain_routes_by_trip) if flixtrain_routes_by_trip is not None else {}};
    
        // Initialiser la carte une fois qu'elle est chargée
        document.addEventListener('DOMContentLoaded', function() {{
            initMap({carte.get_name()});
        }});
        </script>
        '''))
    
    # Sauvegarder la carte
    print("Sauvegarde de la carte...")
    carte.save('carte_transports_temps_reel.html')
    
    # Démarrer le serveur Flask dans un thread séparé
    flask_thread = threading.Thread(target=run_flask_app)
    flask_thread.daemon = True
    flask_thread.start()
    
    # Attendre que le serveur démarre
    time.sleep(1)
    
    # Ouvrir dans le navigateur
    import webbrowser
    webbrowser.open("http://localhost:5000")
    
    print("Serveur démarré sur http://localhost:5000")
    print("Appuyez sur Ctrl+C pour quitter")
    
    try:
        # Garder le programme en cours d'exécution
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Arrêt du programme...")

if __name__ == "__main__":
    main()