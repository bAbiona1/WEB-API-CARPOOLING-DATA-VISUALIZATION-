#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script optimisé pour filtrer et organiser les horaires GTFS par station
Ce script se concentre d'abord sur la zone cible pour réduire le volume de données
"""

import pandas as pd
import os
import datetime
from collections import defaultdict
import json

# Définir le chemin des fichiers d'entrée
input_dir = '/home/ubuntu/upload'
output_dir = '/home/ubuntu/projet_itineraire/data_horaires'

# Créer le répertoire de sortie s'il n'existe pas
os.makedirs(output_dir, exist_ok=True)

print("Chargement des fichiers GTFS originaux...")

# Définir les coordonnées approximatives de la région d'intérêt
# Montbéliard-Belfort-Alsace-Strasbourg
min_lat = 47.0  # Limite sud (approximative)
max_lat = 49.0  # Limite nord (approximative)
min_lon = 6.5   # Limite ouest (approximative)
max_lon = 8.5   # Limite est (approximative)

# Liste des mots-clés pour filtrer par nom
keywords = ['Montbéliard', 'Belfort', 'Mulhouse', 'Colmar', 'Strasbourg', 
            'Alsace', 'Besançon', 'Bâle', 'Basel', 'Mulhouse', 'Nancy', 
            'Franche-Comté', 'Haut-Rhin', 'Bas-Rhin']

print("Filtrage des arrêts pour la zone cible...")

# Charger et filtrer les arrêts par zone géographique
stops = pd.read_csv(os.path.join(input_dir, 'stops.txt'))

# Filtrer les arrêts par coordonnées
stops_geo = stops[
    (stops['stop_lat'] >= min_lat) & 
    (stops['stop_lat'] <= max_lat) & 
    (stops['stop_lon'] >= min_lon) & 
    (stops['stop_lon'] <= max_lon)
]

# Filtrer les arrêts par nom
stops_name = stops[
    stops['stop_name'].str.contains('|'.join(keywords), case=False, na=False)
]

# Combiner les résultats et supprimer les doublons
stops_filtered = pd.concat([stops_geo, stops_name]).drop_duplicates()

print(f"Nombre d'arrêts dans la zone cible: {len(stops_filtered)}")

# Obtenir les IDs des arrêts filtrés
stop_ids_filtered = set(stops_filtered['stop_id'].tolist())

print("Chargement des horaires pour les arrêts de la zone cible...")

# Charger et filtrer les horaires pour les arrêts de la zone cible
stop_times = pd.read_csv(os.path.join(input_dir, 'stop_times.txt'))
stop_times_filtered = stop_times[stop_times['stop_id'].isin(stop_ids_filtered)]

print(f"Nombre d'horaires pour les arrêts de la zone cible: {len(stop_times_filtered)}")

# Obtenir les IDs des trajets qui passent par la zone cible
trip_ids_filtered = set(stop_times_filtered['trip_id'].tolist())

print("Chargement des trajets et routes...")

# Charger les trajets et routes
trips = pd.read_csv(os.path.join(input_dir, 'trips.txt'))
routes = pd.read_csv(os.path.join(input_dir, 'routes.txt'))
agency = pd.read_csv(os.path.join(input_dir, 'agency.txt'))

# Filtrer les trajets qui passent par la zone cible
trips_filtered = trips[trips['trip_id'].isin(trip_ids_filtered)]

print(f"Nombre de trajets passant par la zone cible: {len(trips_filtered)}")

# Obtenir les IDs des routes pour ces trajets
route_ids_filtered = set(trips_filtered['route_id'].tolist())

# Filtrer les routes
routes_filtered = routes[routes['route_id'].isin(route_ids_filtered)]

print(f"Nombre de routes passant par la zone cible: {len(routes_filtered)}")

print("Identification des opérateurs FlixBus et FlixTrain...")

# Identifier les agency_id pour FlixBus et FlixTrain
flixbus_agency_id = agency[agency['agency_name'] == 'FlixBus-eu']['agency_id'].iloc[0]
flixtrain_agency_id = agency[agency['agency_name'] == 'FlixTrain-eu']['agency_id'].iloc[0]

print(f"Agency ID pour FlixBus: {flixbus_agency_id}")
print(f"Agency ID pour FlixTrain: {flixtrain_agency_id}")

# Filtrer les routes par opérateur
flixbus_routes = routes_filtered[routes_filtered['agency_id'] == flixbus_agency_id]
flixtrain_routes = routes_filtered[routes_filtered['agency_id'] == flixtrain_agency_id]

print(f"Nombre de routes FlixBus dans la zone: {len(flixbus_routes)}")
print(f"Nombre de routes FlixTrain dans la zone: {len(flixtrain_routes)}")

# Obtenir les IDs des routes par opérateur
flixbus_route_ids = set(flixbus_routes['route_id'].tolist())
flixtrain_route_ids = set(flixtrain_routes['route_id'].tolist())

# Filtrer les trajets par opérateur
flixbus_trips = trips_filtered[trips_filtered['route_id'].isin(flixbus_route_ids)]
flixtrain_trips = trips_filtered[trips_filtered['route_id'].isin(flixtrain_route_ids)]

print(f"Nombre de trajets FlixBus dans la zone: {len(flixbus_trips)}")
print(f"Nombre de trajets FlixTrain dans la zone: {len(flixtrain_trips)}")

# Obtenir les IDs des trajets par opérateur
flixbus_trip_ids = set(flixbus_trips['trip_id'].tolist())
flixtrain_trip_ids = set(flixtrain_trips['trip_id'].tolist())

# Filtrer les horaires par opérateur
flixbus_stop_times = stop_times_filtered[stop_times_filtered['trip_id'].isin(flixbus_trip_ids)]
flixtrain_stop_times = stop_times_filtered[stop_times_filtered['trip_id'].isin(flixtrain_trip_ids)]

print(f"Nombre d'horaires FlixBus dans la zone: {len(flixbus_stop_times)}")
print(f"Nombre d'horaires FlixTrain dans la zone: {len(flixtrain_stop_times)}")

# Fonction pour corriger le format des heures tout en préservant les valeurs originales
def correct_time_format(time_str):
    if pd.isna(time_str):
        return time_str, time_str
    
    # Extraire les heures, minutes et secondes
    parts = time_str.split(':')
    if len(parts) != 3:
        return time_str, time_str
    
    hours = int(parts[0])
    minutes = int(parts[1])
    seconds = int(parts[2])
    
    # Calculer le jour (0 = même jour, 1 = lendemain, etc.)
    day = hours // 24
    
    # Corriger les heures pour l'affichage (0-23)
    corrected_hours = hours % 24
    
    # Formater l'heure corrigée
    corrected_time = f"{corrected_hours:02d}:{minutes:02d}:{seconds:02d}"
    
    # Ajouter l'information du jour si nécessaire
    if day > 0:
        corrected_time += f" (+{day}j)"
    
    # Retourner à la fois la valeur originale et la valeur corrigée
    return time_str, corrected_time

# Fonction pour obtenir l'heure actuelle
def get_current_time():
    now = datetime.datetime.now()
    current_time = now.strftime("%H:%M:%S")
    return current_time

# Fonction pour comparer les heures (pour le tri)
def compare_times(time_str):
    if pd.isna(time_str):
        return 0
    
    parts = time_str.split(':')
    if len(parts) != 3:
        return 0
    
    hours = int(parts[0])
    minutes = int(parts[1])
    seconds = int(parts[2])
    
    return hours * 3600 + minutes * 60 + seconds

# Fonction pour organiser les horaires par station
def organize_schedules_by_station(stop_times_df, trips_df, routes_df, stops_df):
    # Créer un dictionnaire pour stocker les horaires par station
    station_schedules = defaultdict(list)
    
    # Parcourir tous les horaires
    for _, row in stop_times_df.iterrows():
        stop_id = row['stop_id']
        trip_id = row['trip_id']
        arrival_time_orig, arrival_time_corr = correct_time_format(row['arrival_time'])
        departure_time_orig, departure_time_corr = correct_time_format(row['departure_time'])
        stop_sequence = row['stop_sequence']
        
        # Obtenir les informations du trajet
        trip_info = trips_df[trips_df['trip_id'] == trip_id]
        if not trip_info.empty:
            route_id = trip_info['route_id'].iloc[0]
            
            # Obtenir les informations de la route
            route_info = routes_df[routes_df['route_id'] == route_id]
            if not route_info.empty:
                route_name = route_info['route_long_name'].iloc[0]
                route_short_name = route_info['route_short_name'].iloc[0] if 'route_short_name' in route_info.columns and pd.notna(route_info['route_short_name'].iloc[0]) else ""
                
                # Ajouter les informations à la liste des horaires de la station
                station_schedules[stop_id].append({
                    'trip_id': trip_id,
                    'route_id': route_id,
                    'route_name': route_name,
                    'route_short_name': route_short_name,
                    'arrival_time_orig': arrival_time_orig,
                    'arrival_time_corr': arrival_time_corr,
                    'departure_time_orig': departure_time_orig,
                    'departure_time_corr': departure_time_corr,
                    'stop_sequence': stop_sequence,
                    'sort_key': compare_times(departure_time_orig)
                })
    
    # Trier les horaires par heure de départ pour chaque station
    for stop_id in station_schedules:
        station_schedules[stop_id].sort(key=lambda x: x['sort_key'])
    
    return station_schedules

# Organiser les horaires par station
print("Organisation des horaires par station...")
flixbus_station_schedules = organize_schedules_by_station(flixbus_stop_times, flixbus_trips, flixbus_routes, stops)
flixtrain_station_schedules = organize_schedules_by_station(flixtrain_stop_times, flixtrain_trips, flixtrain_routes, stops)

print(f"Nombre de stations FlixBus avec horaires: {len(flixbus_station_schedules)}")
print(f"Nombre de stations FlixTrain avec horaires: {len(flixtrain_station_schedules)}")

# Fonction pour filtrer les horaires de la journée courante
def filter_current_day_schedules(schedules, current_time):
    # Convertir l'heure actuelle en secondes depuis minuit
    current_seconds = compare_times(current_time)
    
    # Filtrer les horaires
    filtered_schedules = []
    for schedule in schedules:
        departure_seconds = schedule['sort_key']
        # Garder uniquement les horaires après l'heure actuelle et avant minuit
        if departure_seconds >= current_seconds and departure_seconds < 24 * 3600:
            filtered_schedules.append(schedule)
    
    return filtered_schedules

# Obtenir l'heure actuelle
current_time = get_current_time()
print(f"Heure actuelle: {current_time}")

# Filtrer les horaires pour la journée courante
print("Filtrage des horaires pour la journée courante...")
flixbus_station_schedules_today = {}
for stop_id, schedules in flixbus_station_schedules.items():
    flixbus_station_schedules_today[stop_id] = filter_current_day_schedules(schedules, current_time)

flixtrain_station_schedules_today = {}
for stop_id, schedules in flixtrain_station_schedules.items():
    flixtrain_station_schedules_today[stop_id] = filter_current_day_schedules(schedules, current_time)

# Compter le nombre total d'horaires pour aujourd'hui
flixbus_today_count = sum(len(schedules) for schedules in flixbus_station_schedules_today.values())
flixtrain_today_count = sum(len(schedules) for schedules in flixtrain_station_schedules_today.values())

print(f"Nombre d'horaires FlixBus pour aujourd'hui: {flixbus_today_count}")
print(f"Nombre d'horaires FlixTrain pour aujourd'hui: {flixtrain_today_count}")

# Sauvegarder les horaires organisés au format JSON
print("Sauvegarde des horaires au format JSON...")

# Convertir les defaultdict en dictionnaires réguliers pour la sérialisation JSON
flixbus_schedules_json = {stop_id: schedules for stop_id, schedules in flixbus_station_schedules.items()}
flixtrain_schedules_json = {stop_id: schedules for stop_id, schedules in flixtrain_station_schedules.items()}

flixbus_schedules_today_json = {stop_id: schedules for stop_id, schedules in flixbus_station_schedules_today.items()}
flixtrain_schedules_today_json = {stop_id: schedules for stop_id, schedules in flixtrain_station_schedules_today.items()}

# Sauvegarder les horaires au format JSON
with open(os.path.join(output_dir, 'flixbus_schedules.json'), 'w') as f:
    json.dump(flixbus_schedules_json, f)

with open(os.path.join(output_dir, 'flixtrain_schedules.json'), 'w') as f:
    json.dump(flixtrain_schedules_json, f)

with open(os.path.join(output_dir, 'flixbus_schedules_today.json'), 'w') as f:
    json.dump(flixbus_schedules_today_json, f)

with open(os.path.join(output_dir, 'flixtrain_schedules_today.json'), 'w') as f:
    json.dump(flixtrain_schedules_today_json, f)

# Sauvegarder également les arrêts filtrés
stops_filtered.to_csv(os.path.join(output_dir, 'stops_filtered.csv'), index=False)

print("Organisation des horaires terminée. Les fichiers ont été sauvegardés dans le répertoire", output_dir)

# Afficher quelques exemples d'horaires organisés
print("\nExemples d'horaires FlixBus organisés:")
for stop_id, schedules in list(flixbus_station_schedules_today.items())[:2]:
    stop_name = stops[stops['stop_id'] == stop_id]['stop_name'].iloc[0] if len(stops[stops['stop_id'] == stop_id]) > 0 else "Inconnu"
    print(f"\nStation: {stop_name} (ID: {stop_id})")
    print("Horaires d'aujourd'hui:")
    for i, schedule in enumerate(schedules[:5]):  # Limiter à 5 horaires par station
        print(f"  {i+1}. Ligne: {schedule['route_short_name']} - {schedule['route_name']}")
        print(f"     Arrivée: {schedule['arrival_time_corr']}")
        print(f"     Départ: {schedule['departure_time_corr']}")
    if len(schedules) > 5:
        print(f"     ... et {len(schedules) - 5} autres horaires")

print("\nExemples d'horaires FlixTrain organisés:")
for stop_id, schedules in list(flixtrain_station_schedules_today.items())[:2]:
    stop_name = stops[stops['stop_id'] == stop_id]['stop_name'].iloc[0] if len(stops[stops['stop_id'] == stop_id]) > 0 else "Inconnu"
    print(f"\nStation: {stop_name} (ID: {stop_id})")
    print("Horaires d'aujourd'hui:")
    for i, schedule in enumerate(schedules[:5]):  # Limiter à 5 horaires par station
        print(f"  {i+1}. Ligne: {schedule['route_short_name']} - {schedule['route_name']}")
        print(f"     Arrivée: {schedule['arrival_time_corr']}")
        print(f"     Départ: {schedule['departure_time_corr']}")
    if len(schedules) > 5:
        print(f"     ... et {len(schedules) - 5} autres horaires")

# Créer un dictionnaire pour stocker les trajets complets par trip_id
print("\nExtraction des trajets complets...")

# Charger tous les horaires pour les trajets qui passent par la zone
all_trip_stop_times = stop_times[stop_times['trip_id'].isin(trip_ids_filtered)]
print(f"Nombre total d'horaires pour les trajets passant par la zone: {len(all_trip_stop_times)}")

# Organiser les trajets complets
trip_routes = {}
for trip_id in trip_ids_filtered:
    # Obtenir tous les arrêts du trajet, triés par séquence
    trip_stops = all_trip_stop_times[all_trip_stop_times['trip_id'] == trip_id].sort_values('stop_sequence')
    
    # Collecter les informations sur les arrêts
    stops_info = []
    for _, stop_row in trip_stops.iterrows():
        stop_id = stop_row['stop_id']
        stop_info = stops[stops['stop_id'] == stop_id]
        if not stop_info.empty:
            stops_info.append({
                'stop_id': stop_id,
                'stop_name': stop_info['stop_name'].iloc[0],
                'stop_lat': float(stop_info['stop_lat'].iloc[0]),
                'stop_lon': float(stop_info['stop_lon'].iloc[0]),
                'arrival_time': stop_row['arrival_time'],
                'departure_time': stop_row['departure_time'],
                'stop_sequence': int(stop_row['stop_sequence'])
            })
    
    # Ajouter le trajet au dictionnaire
    if stops_info:
        trip_routes[trip_id] = stops_info

print(f"Nombre de trajets complets extraits: {len(trip_routes)}")

# Séparer les trajets FlixBus et FlixTrain
flixbus_trip_routes = {trip_id: stops for trip_id, stops in trip_routes.items() if trip_id in flixbus_trip_ids}
flixtrain_trip_routes = {trip_id: stops for trip_id, stops in trip_routes.items() if trip_id in flixtrain_trip_ids}

print(f"Nombre de trajets complets FlixBus: {len(flixbus_trip_routes)}")
print(f"Nombre de trajets complets FlixTrain: {len(flixtrain_trip_routes)}")

# Sauvegarder les trajets complets au format JSON
with open(os.path.join(output_dir, 'flixbus_trip_routes.json'), 'w') as f:
    json.dump(flixbus_trip_routes, f)

with open(os.path.join(output_dir, 'flixtrain_trip_routes.json'), 'w') as f:
    json.dump(flixtrain_trip_routes, f)

print("Extraction des trajets complets terminée.")

# Charger les shapes pour les trajets
print("\nChargement des shapes pour les trajets...")
shapes = pd.read_csv(os.path.join(input_dir, 'shapes.txt'))

# Obtenir les shape_ids pour les trajets filtrés
shape_ids = set()
for _, trip in trips_filtered.iterrows():
    if pd.notna(trip['shape_id']):
        shape_ids.add(trip['shape_id'])

print(f"Nombre de shapes à extraire: {len(shape_ids)}")

# Filtrer les shapes
shapes_filtered = shapes[shapes['shape_id'].isin(shape_ids)]
print(f"Nombre de points de shapes filtrés: {len(shapes_filtered)}")

# Organiser les shapes par shape_id
shapes_by_id = defaultdict(list)
for _, row in shapes_filtered.iterrows():
    shapes_by_id[row['shape_id']].append({
        'lat': float(row['shape_pt_lat']),
        'lon': float(row['shape_pt_lon']),
        'sequence': int(row['shape_pt_sequence'])
    })

# Trier les points de shape par séquence
for shape_id in shapes_by_id:
    shapes_by_id[shape_id].sort(key=lambda x: x['sequence'])

# Convertir en format JSON
shapes_json = {shape_id: points for shape_id, points in shapes_by_id.items()}

# Sauvegarder les shapes au format JSON
with open(os.path.join(output_dir, 'shapes.json'), 'w') as f:
    json.dump(shapes_json, f)

# Créer un mapping entre trip_id et shape_id
trip_to_shape = {}
for _, trip in trips_filtered.iterrows():
    if pd.notna(trip['shape_id']):
        trip_to_shape[trip['trip_id']] = trip['shape_id']

# Sauvegarder le mapping au format JSON
with open(os.path.join(output_dir, 'trip_to_shape.json'), 'w') as f:
    json.dump(trip_to_shape, f)

print("Extraction des shapes terminée.")
